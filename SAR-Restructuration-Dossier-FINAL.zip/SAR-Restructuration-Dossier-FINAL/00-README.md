# SAR — Dossier complet de restructuration BD (Supabase) — “Dossier médical client” (FINAL)
Date: 2026-01-14
Décision clé client: **A — courriel prioritaire + fallback telephone**

✅ **Aligné sur ton blueprint fourni** (`SAR-STRUCTURE-COMPLETE.md`, généré 2026-01-14).

## Objectif
Centraliser dans Supabase **tout l’historique client** (infos perso, données financières, fichiers, communications email/SMS, notes, NSF, ajustements, reports, grilles, VoPay) afin qu’une **nouvelle demande** affiche instantanément le dossier complet, comme un dossier médical.

## Ce que ce pack apporte
- `clients` (client canonique / “patient id”)
- Ajout `client_id` sur tables existantes critiques
- `communications` (email/sms/support/internal) + migration depuis `emails_envoyes`
- `loans` + `payment_*` (versionnement + événements) **sans casser** ton ledger `client_transactions`
- `vopay_objects` normalisé (en gardant `vopay_webhook_logs` raw)
- `vw_client_timeline` + `vw_client_summary` (dossier médical instantané)
- Checklists + tests + journalisation

## Structure
- `PHASES/` : plan par phases.
- `MIGRATIONS/sql/` : scripts SQL numérotés.
- `CHECKLISTS/` : checklists à cocher.
- `TESTS/sql/` : tests SQL + scénarios manuels.
- `JOURNAL/` : logbook + status board.
- `CLAUDECODE_RUNBOOK.md` : instructions d’exécution pour Claude Code.

## Règles anti-chaos
- Une phase à la fois.
- Aucun “edit silencieux” : si ça impacte paiements / schedule / décision / communications → ça doit générer un événement (history/timeline).
- Toutes les entités importantes doivent pointer vers `client_id`.
