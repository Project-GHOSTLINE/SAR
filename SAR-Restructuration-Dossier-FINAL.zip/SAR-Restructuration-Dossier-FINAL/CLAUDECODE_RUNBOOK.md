# Claude Code — Runbook exécution (SAR) — FINAL

## Branche
- `git checkout -b chore/db-dossier-medical`

## Ordre d’exécution SQL (staging d’abord)
1) `MIGRATIONS/sql/000_baseline_snapshot.sql`

### Phase 1 — Clients (canonique)
2) `MIGRATIONS/sql/010_create_clients.sql`
3) `MIGRATIONS/sql/011_add_client_id_columns.sql`
4) `MIGRATIONS/sql/012_backfill_clients.sql`

### Phase 2 — Communications unifiées
5) `MIGRATIONS/sql/020_create_communications.sql`
6) `MIGRATIONS/sql/021_migrate_emails_envoyes_to_communications.sql`
7) `MIGRATIONS/sql/022_view_support_as_communications.sql` (optionnel mais recommandé)

### Phase 3 — Loans + payment schedules versionnés
8) `MIGRATIONS/sql/030_create_loans_and_payments.sql`
9) `MIGRATIONS/sql/031_backfill_loans_from_client_accounts.sql`

### Phase 4 — VoPay normalisé
10) `MIGRATIONS/sql/040_create_vopay_objects.sql`
11) `MIGRATIONS/sql/041_backfill_vopay_objects.sql` (optionnel)

### Phase 5 — Vues dossier médical
12) `MIGRATIONS/sql/050_create_timeline_views.sql`

## Tests après chaque phase
- P0 → `TESTS/sql/000_baseline_checks.sql`
- P1 → `TESTS/sql/010_clients_integrity.sql`
- P2 → `TESTS/sql/020_communications_integrity.sql`
- P3 → `TESTS/sql/030_payments_integrity.sql`
- P4 → `TESTS/sql/040_vopay_integrity.sql`
- P5 → `TESTS/sql/050_timeline_views.sql`

## Journalisation (obligatoire)
À chaque fichier SQL exécuté :
- Calculer SHA256
- Écrire une entrée dans `JOURNAL/LOGBOOK.md`
