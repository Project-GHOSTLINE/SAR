# Checklist — Phase 2: Communications

- [ ] Exécuter 020_create_communications.sql
- [ ] Exécuter 021_migrate_emails_envoyes_to_communications.sql
- [ ] Exécuter 022_view_support_as_communications.sql (recommandé)
- [ ] Tests: TESTS/sql/020_communications_integrity.sql
- [ ] Vérifier: 10 emails envoyés apparaissent via vw_client_timeline (après P5)
