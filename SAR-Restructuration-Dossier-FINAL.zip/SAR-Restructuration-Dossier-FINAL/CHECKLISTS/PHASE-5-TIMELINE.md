# Checklist — Phase 5: Timeline + Summary

- [ ] Exécuter 050_create_timeline_views.sql
- [ ] Tests: TESTS/sql/050_timeline_views.sql
- [ ] Vérifier 3 clients: timeline montre communications + ledger + fraude (si dispo)
