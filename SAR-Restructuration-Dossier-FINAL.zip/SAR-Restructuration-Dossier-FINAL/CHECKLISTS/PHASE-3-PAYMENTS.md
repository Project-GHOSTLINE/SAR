# Checklist — Phase 3: Loans & Payments

- [ ] Exécuter 030_create_loans_and_payments.sql
- [ ] Exécuter 031_backfill_loans_from_client_accounts.sql
- [ ] Tests: TESTS/sql/030_payments_integrity.sql
