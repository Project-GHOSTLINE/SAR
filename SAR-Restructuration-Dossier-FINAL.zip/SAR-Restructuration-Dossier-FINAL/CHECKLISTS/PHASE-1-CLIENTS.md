# Checklist — Phase 1: Client canonique

Objectif: créer `clients` + remplir `client_id` sur les objets existants.

- [ ] Exécuter 010_create_clients.sql
- [ ] Exécuter 011_add_client_id_columns.sql
- [ ] Exécuter 012_backfill_clients.sql
- [ ] Tests: TESTS/sql/010_clients_integrity.sql
- [ ] Vérifier 10 dossiers: loan_applications.client_id rempli
