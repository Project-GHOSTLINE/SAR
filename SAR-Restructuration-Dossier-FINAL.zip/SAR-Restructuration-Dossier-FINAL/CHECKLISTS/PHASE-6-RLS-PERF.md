# Checklist — Phase 6: RLS + audit + perf (après validation fonctionnelle)

- [ ] Activer RLS sur: clients, communications, loans, payment_*, vopay_objects
- [ ] Policies par rôle (admin / analyst / support)
- [ ] Index perf revus (client_id, occurred_at, created_at)
- [ ] EXPLAIN ANALYZE sur vw_client_timeline pour client moyen
