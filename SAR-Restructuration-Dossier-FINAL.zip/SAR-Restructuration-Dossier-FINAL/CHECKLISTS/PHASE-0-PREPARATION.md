# Checklist — Phase 0: Préparation (obligatoire)

Environnement
- [ ] Staging/clone DB disponible
- [ ] Accès DB (service role) confirmé

Sauvegarde
- [ ] Backup complet DB (snapshot)
- [ ] Export schema actuel
- [ ] Baseline exécutée (`TESTS/sql/000_baseline_checks.sql`)

Inventaire rapide (blueprint)
- [ ] Tables présentes: loan_applications, client_accounts, client_transactions, client_analyses
- [ ] Tables présentes: emails_envoyes, contact_messages, support_tickets/support_messages/support_attachments
- [ ] Tables présentes: vopay_webhook_logs, fraud_cases
