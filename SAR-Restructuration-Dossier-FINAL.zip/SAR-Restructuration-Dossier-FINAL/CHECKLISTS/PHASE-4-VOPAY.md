# Checklist — Phase 4: VoPay normalisé

- [ ] Exécuter 040_create_vopay_objects.sql
- [ ] (Optionnel) Exécuter 041_backfill_vopay_objects.sql
- [ ] Tests: TESTS/sql/040_vopay_integrity.sql
