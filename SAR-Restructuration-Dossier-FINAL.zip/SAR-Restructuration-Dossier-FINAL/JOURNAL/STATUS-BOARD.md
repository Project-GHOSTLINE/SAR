# Status Board — Restructuration SAR — FINAL

- [ ] P0 — Préparation
- [ ] P1 — Clients + liens client_id
- [ ] P2 — Communications (emails_envoyes + support view)
- [ ] P3 — Loans + payment schedules/events
- [ ] P4 — VoPay normalisé
- [ ] P5 — Timeline + Summary views
- [ ] P6 — RLS + audit + performance

Décision figée: **client match = courriel (prioritaire) + telephone (fallback)**.
