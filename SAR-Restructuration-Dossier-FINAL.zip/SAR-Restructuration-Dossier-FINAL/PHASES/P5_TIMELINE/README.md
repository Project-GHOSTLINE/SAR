Phase 5 — Timeline/Summary. Voir MIGRATIONS/sql/050 et CHECKLISTS/PHASE-5-TIMELINE.md
