Phase 1 — Clients canonique. Voir MIGRATIONS/sql/010-012 et CHECKLISTS/PHASE-1-CLIENTS.md
