# Phase 1 — Client canonique

## Objectif
Créer un identifiant client stable (`clients`) et relier:
- demandes (`loan_applications`)
- comptes (`client_accounts`)
- analyses (`client_analyses`)
- fichiers (`client_folders`, `client_documents`)
- support/contact (si applicable)

## Stratégie de match initial
1) Match exact email (case-insensitive)
2) Sinon match téléphone exact
3) Sinon créer nouveau client

## Livrables
- table `clients`
- colonnes `client_id` ajoutées
- backfill relié

## Rollback (concept)
- Ne pas dropper `clients` en prod si déjà référencé.
- Rollback safe: conserver `clients`, mais remettre `client_id` à NULL sur tables existantes (script à ajouter si nécessaire).
