# Phase 4 — VoPay normalisé

## Objectif
- Conserver logs bruts: `vopay_webhook_logs`
- Créer des objets lisibles dossier: `vopay_objects`

## Idempotence
- index unique (object_type, vopay_id)
- ingestion doit être safe si webhook est rejoué
