# Phase 3 — Paiements versionnés

## Objectif
- Ledger réel = `client_transactions` (déjà présent)
- Planification & modifications = `payment_schedule_versions`, `payment_installments`, `payment_events`

## Règles
- Toute modification de grille = nouvelle `payment_schedule_versions.version`
- Tout événement notable = `payment_events` (NSF, report, frais, promesse, ajustement)
