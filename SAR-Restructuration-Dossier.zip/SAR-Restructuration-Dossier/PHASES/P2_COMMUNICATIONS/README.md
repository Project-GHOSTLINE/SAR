# Phase 2 — Communications (Email/SMS)

## Objectif
Avoir une table unifiée pour tout ce qui est communiqué avec le client (inbound/outbound):
- email (info@ / support / notifications)
- SMS
- (optionnel) support messages

## Threading
- `thread_key`: basé sur Message-ID / References / In-Reply-To (email)
- fallback: subject normalisé + participants

## Attachements
- Table `communication_attachments` + Supabase Storage
- Convention path: `client/<client_id>/communications/<communication_id>/<filename>`
