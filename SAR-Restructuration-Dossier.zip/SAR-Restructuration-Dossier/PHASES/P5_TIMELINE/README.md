# Phase 5 — Timeline & vues dossier médical

## Objectif
- Une timeline universelle triable
- Une vue summary KPI

## Attention
Le bloc `PAYMENT_EVENT` de la vue doit JOIN `loans` pour obtenir `client_id`.
