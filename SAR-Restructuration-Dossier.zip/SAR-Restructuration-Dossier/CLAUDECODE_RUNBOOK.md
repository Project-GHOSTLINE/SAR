# Claude Code — Runbook exécution (SAR)

But: Claude Code doit pouvoir exécuter les phases sans mélanger et journaliser.

## Étape 1 — Créer une branche
- `git checkout -b chore/db-restructuration-dossier-medical`

## Étape 2 — Variables
- DB_URL / SUPABASE_DB_URL
- SERVICE_ROLE_KEY (si nécessaire pour scripts)
- (Optionnel) SUPABASE_PROJECT_REF

## Étape 3 — Ordre d’exécution SQL
Exécuter dans l’ordre:

1) `MIGRATIONS/sql/000_baseline_snapshot.sql`
2) Phase 1:
   - `010_create_clients.sql`
   - `011_add_client_id_columns.sql`
   - `012_backfill_clients_from_loan_applications.sql` (ADAPTER colonnes)
3) Phase 2:
   - `020_create_communications.sql`
   - `021_migrate_emails_envoyes_to_communications.sql` (si table existe + adapter)
4) Phase 3:
   - `030_create_loans_and_payments.sql`
5) Phase 4:
   - `040_create_vopay_objects.sql`
6) Phase 5:
   - `050_create_timeline_views.sql` (corriger join loans->events)

## Étape 4 — Tests après chaque phase
- Phase 1 → `TESTS/sql/010_clients_integrity.sql`
- Phase 2 → `TESTS/sql/020_communications_integrity.sql`
- Phase 3 → `TESTS/sql/030_payments_integrity.sql`
- Phase 4 → `TESTS/sql/040_vopay_integrity.sql`
- Phase 5 → `TESTS/sql/050_timeline_views.sql`

## Étape 5 — Journalisation (obligatoire)
À chaque exécution de migration:
- Calculer SHA256 du fichier
- Coller une entrée dans `JOURNAL/LOGBOOK.md`

## Points qui demandent adaptation (TODO)
- Colonnes réelles de `loan_applications` (email/tel/prénom/nom)
- Structure réelle de `emails_envoyes`
- Lien VoPay webhook → client (metadata)
- RLS/policies selon tes rôles (admin/analyst/support)

> Recommandation: intégrer ces TODO dans une passe “inventory” avant de lancer le backfill.
