# Checklist — Phase 2: Communications (Email/SMS) unifiées

Objectif: centraliser inbound/outbound (email+sms+support optionnel) dans `communications`.

## Pré-check
- [ ] `clients` existant + `client_id` disponible
- [ ] Choix stockage body email: DB (texte) ou Storage (ref)
- [ ] Choix threading: `thread_key` (Message-ID/References/subject normalized)

## Exécution
- [ ] Migrations SQL P2 exécutées
- [ ] Mapping legacy: `emails_envoyes` → `communications` (outbound)
- [ ] Ajout `communication_attachments`
- [ ] (Optionnel) VIEW de compatibilité pour l’existant

## Tests
- [ ] TESTS/sql/020_communications_integrity.sql OK
- [ ] 10 emails legacy migrés: participants corrects, timestamps, client_id
- [ ] Permissions/RLS testées (support vs analyst)

## Post-check
- [ ] Timeline commence à afficher communications
- [ ] Journal mis à jour
