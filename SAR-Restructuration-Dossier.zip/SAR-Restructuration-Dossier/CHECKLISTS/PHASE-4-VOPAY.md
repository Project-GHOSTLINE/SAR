# Checklist — Phase 4: VoPay normalisé

Objectif: conserver raw (`vopay_webhook_logs`) + créer objets lisibles dossier (`vopay_objects`).

## Exécution
- [ ] Migrations SQL P4 exécutées
- [ ] Parser minimal: webhook_logs → vopay_objects (type, id, status, amount)
- [ ] Mapping client_id/loan_id quand possible (via metadata)

## Tests
- [ ] TESTS/sql/040_vopay_integrity.sql OK
- [ ] 10 webhooks: objets créés, non dupliqués
- [ ] Idempotence vérifiée (replay webhook)

## Post-check
- [ ] Timeline affiche VoPay
- [ ] Journal mis à jour
