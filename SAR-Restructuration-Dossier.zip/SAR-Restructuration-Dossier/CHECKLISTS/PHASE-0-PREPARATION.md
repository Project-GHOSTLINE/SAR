# Checklist — Phase 0: Préparation (obligatoire)

## Environnement
- [ ] Staging (ou DB clone) disponible
- [ ] Variables d’environnement (DB URL / service role) validées
- [ ] Fenêtre de maintenance définie (si prod)

## Sauvegarde & sécurité
- [ ] Backup complet DB (export/snapshot)
- [ ] Backup Storage (ou plan de restauration)
- [ ] Export schema actuel (`pg_dump --schema-only`)
- [ ] Export RLS policies (si possible)

## Inventaire (anti-surprises)
- [ ] Lister tables existantes + colonnes clés
- [ ] Identifier clés primaires/FK existantes
- [ ] Lister triggers & functions actuelles
- [ ] Lister index existants + tailles tables

## Stratégie migration
- [ ] “client match” défini (email+phone)
- [ ] Approche: ajouter `client_id` sans casser l’existant
- [ ] Plan rollback pour chaque phase (scripts inclus)

## Tests avant changement
- [ ] TESTS/sql/000_baseline_checks.sql exécuté
- [ ] Temps de requêtes critiques mesuré (baseline perf)
