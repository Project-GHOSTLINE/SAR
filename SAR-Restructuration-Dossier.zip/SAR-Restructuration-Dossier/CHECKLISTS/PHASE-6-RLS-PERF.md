# Checklist — Phase 6: RLS + audit + performance

## RLS
- [ ] RLS activé sur nouvelles tables
- [ ] Policies par rôle: admin / analyst / collections / support
- [ ] Test: aucun accès cross-tenant (si multi-tenant)

## Audit
- [ ] Triggers: changements sensibles (schedule, décision, notes critiques)
- [ ] `created_by`, `updated_by` remplis
- [ ] Log d’erreurs ingestion email/sms

## Performance
- [ ] Index sur `client_id`, `loan_id`, `sent_at/received_at`
- [ ] EXPLAIN ANALYZE sur queries principales
