# Checklist — Phase 3: Prêts & paiements versionnés

Objectif: garder ledger (`client_transactions`) ET ajouter:
- `loans`
- `payment_schedule_versions`
- `payment_installments`
- `payment_events`

## Pré-check
- [ ] Tables existantes de transactions identifiées
- [ ] Décision: source of truth schedule = Margill / SAR / mix

## Exécution
- [ ] Migrations SQL P3 exécutées
- [ ] Backfill `loans` depuis comptes actifs + applications
- [ ] Création version 1 de schedule (si possible) ou placeholder
- [ ] Événements NSF/reports importés si données existantes

## Tests
- [ ] TESTS/sql/030_payments_integrity.sql OK
- [ ] 5 prêts: schedule versions consultables + ledger cohérent
- [ ] “Modification de grille” crée une nouvelle version (test manuel)

## Post-check
- [ ] Index perf OK
- [ ] Journal mis à jour
