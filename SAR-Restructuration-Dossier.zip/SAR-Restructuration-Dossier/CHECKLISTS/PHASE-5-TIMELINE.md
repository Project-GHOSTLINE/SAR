# Checklist — Phase 5: Timeline universelle + vues

Objectif: une vue “dossier médical” ultra rapide (résumé + timeline) sans multiplier les requêtes.

## Exécution
- [ ] Migrations SQL P5 exécutées
- [ ] `vw_client_timeline` créée (UNION ALL + normalisation)
- [ ] `vw_client_summary` créée (KPI)

## Tests
- [ ] TESTS/sql/050_timeline_views.sql OK
- [ ] 3 clients: timeline montre emails, notes, events, transactions, documents
- [ ] Perf: timeline < 300ms sur client moyen (baseline + mesure)

## Post-check
- [ ] Journal mis à jour
