# Checklist — Phase 1: Client canonique

Objectif: créer `clients` (patient id) + relier les objets existants via `client_id`.

## Pré-check
- [ ] Phase 0 complétée
- [ ] Décision sur dédoublonnage: email+tel (recommandé)
- [ ] Format téléphone normalisé (E.164 ou standard interne)

## Exécution
- [ ] Migrations SQL P1 exécutées (00xx)
- [ ] Backfill clients depuis `loan_applications` (et support si présent)
- [ ] `client_id` ajouté sur tables cibles (sans casser les requêtes existantes)

## Tests
- [ ] TESTS/sql/010_clients_integrity.sql OK
- [ ] Duplicats contrôlés (rapport généré)
- [ ] 5 clients au hasard: leurs applications correctement reliées

## Post-check
- [ ] Index sur `client_id` ajouté
- [ ] Journal mis à jour
