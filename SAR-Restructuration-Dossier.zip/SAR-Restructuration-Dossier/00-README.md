# SAR — Dossier complet de restructuration BD (Supabase) — “Dossier médical client”
Date: 2026-01-14

Ce dépôt (à copier tel quel dans ton repo **SAR**) contient un plan **phases**, des scripts SQL, une checklist, des tests, et un **livre de journalisation** pour suivre l’exécution sans mélanger les changements.

## Objectif
Centraliser dans Supabase **tout l’historique client** (infos perso, données financières, fichiers, communications email/SMS, notes, NSF, ajustements, reports, grilles, VoPay) afin qu’une **nouvelle demande** affiche instantanément le dossier complet, comme un dossier médical canadien.

## Hypothèses (modifiables)
- Les tables existantes typiques mentionnées dans ton projet: `loan_applications`, `client_accounts`, `client_transactions`, `client_analyses`, `client_folders`, `client_documents`, `support_tickets`, `support_messages`, `support_attachments`, `contact_messages`, `emails_envoyes`, `notes_internes`, `vopay_webhook_logs`, `fraud_cases`.
- Le “match” client initial sera fait sur **email + téléphone** (avec tolérance). Voir Phase 1.

> ⚠️ IMPORTANT: Exécute dans un environnement de test/staging d’abord, puis production. Utilise les checklists + tests.

---

## Structure du dossier
- `PHASES/` : chaque phase = objectifs, SQL, rollback, validation.
- `MIGRATIONS/` : scripts SQL numérotés (prêts à exécuter).
- `CHECKLISTS/` : checklists opérationnelles + techniques.
- `TESTS/` : tests SQL + scénarios manuels (UI) + validations RLS.
- `JOURNAL/` : logbook + templates de suivi (exécution, incidents, décisions).

---

## Exécution rapide (résumé)
1. Lis `JOURNAL/LOGBOOK.md` (comment journaliser proprement).
2. Phase 0 (préparation) → backup + snapshot + staging.
3. Exécute les migrations dans l’ordre `MIGRATIONS/sql/*.sql`.
4. Après chaque phase: exécute les tests `TESTS/sql/*.sql` + checklist.
5. Journalise tout (résultats, anomalies, décisions, rollback si besoin).

---

## Très important (anti-chaos)
- **Une phase à la fois**.
- Interdire les “edits silencieux”: toute modification sensible doit laisser une trace (`*_events`, `*_history`, `timeline`).
- Règle d’or: tout objet important doit pointer vers `client_id` et être horodaté.
