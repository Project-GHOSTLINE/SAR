# Status Board — Restructuration SAR

## Légende
- ✅ Done
- ⏳ In progress
- ⛔ Blocked
- 🧪 Needs tests
- 🔁 Needs rollback review

## Phases
- [ ] P0 — Préparation (backup, staging, inventaire, RLS review)
- [ ] P1 — Client canonique (`clients`) + liens `client_id`
- [ ] P2 — Communications unifiées (`communications`, attachments, threads)
- [ ] P3 — Prêts & paiements versionnés (`loans`, schedules, events)
- [ ] P4 — Normalisation VoPay (raw → objets lisibles)
- [ ] P5 — Timeline universelle + vues “dossier médical”
- [ ] P6 — Durcissement RLS + audit + performance (indexes)
- [ ] P7 — Migration UI & endpoints (si applicable)

## Points ouverts / décisions
- Match client: email+tel (tolérance?) / email only? / tel only?
- Stockage body email: DB vs Storage
- PII/IBV raw: encryption / bucket policies
