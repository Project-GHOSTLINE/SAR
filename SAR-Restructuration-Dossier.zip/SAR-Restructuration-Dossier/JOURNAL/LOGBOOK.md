# Livre de journalisation — Restructuration SAR (Supabase)

Ce document sert à **éviter le mélange**. Chaque action exécutée doit être enregistrée ici.

## Convention de nommage
- Entrée de journal = `YYYY-MM-DD HH:MM` (America/Montreal) + auteur + phase + action.
- Chaque migration exécutée → note le hash (SHA) et le résultat.

## Template d’entrée (copier/coller)
```
[DATE HEURE] — Auteur: <nom> — Phase: <P#> — Action: <description>

Objectif:
- ...

Pré-conditions vérifiées:
- [ ] Backup
- [ ] Staging OK
- [ ] Tests pré-phase OK

Commandes / migrations:
- Fichier: MIGRATIONS/sql/00xx_....sql
- SHA256: <colle le hash>
- Résultat: OK / FAIL
- Détails: ...

Post-conditions:
- [ ] Tests post-phase OK (réf: TESTS/sql/....sql)
- [ ] Checklist phase complétée

Incidents / décisions:
- Incident: ...
- Root cause (si connu): ...
- Décision: ...
- Rollback: Oui/Non (si oui: fichier rollback + résultat)

Next steps:
- ...
```

## Journal — Entrées
(ajoute tes entrées sous cette ligne)
