-- Phase 3 tests

SELECT to_regclass('public.loans') AS loans_table;
SELECT to_regclass('public.payment_schedule_versions') AS schedule_versions_table;
SELECT to_regclass('public.payment_installments') AS installments_table;
SELECT to_regclass('public.payment_events') AS payment_events_table;

-- loans orphelins (sans client)
SELECT COUNT(*) AS loans_without_client
FROM public.loans l
LEFT JOIN public.clients c ON c.id=l.client_id
WHERE c.id IS NULL;

-- version uniqueness check already enforced; just show suspicious
SELECT loan_id, version, COUNT(*) FROM public.payment_schedule_versions
GROUP BY 1,2 HAVING COUNT(*) > 1;
