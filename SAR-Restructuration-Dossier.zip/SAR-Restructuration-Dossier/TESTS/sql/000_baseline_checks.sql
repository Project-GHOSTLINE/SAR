-- Baseline sanity checks (adapter si noms diffèrent)
SELECT now() AS executed_at;

-- Vérifier existence tables clés (après P1+)
-- SELECT to_regclass('public.clients') IS NOT NULL AS has_clients;

-- Exemple: compter applications sans email/tel (à adapter)
-- SELECT COUNT(*) AS apps_missing_contact FROM public.loan_applications WHERE (email IS NULL OR email='') AND (phone IS NULL OR phone='');
