-- Phase 4 tests

SELECT to_regclass('public.vopay_objects') AS vopay_objects_table;

-- duplicates (should be 0 because unique index)
SELECT object_type, vopay_id, COUNT(*)
FROM public.vopay_objects
GROUP BY 1,2 HAVING COUNT(*) > 1;
