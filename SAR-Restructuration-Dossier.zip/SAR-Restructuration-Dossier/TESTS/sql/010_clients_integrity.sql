-- Phase 1 tests

-- 1) clients existe
SELECT to_regclass('public.clients') AS clients_table;

-- 2) ratio de liaison applications -> clients
SELECT
  COUNT(*) AS total_apps,
  SUM(CASE WHEN client_id IS NULL THEN 1 ELSE 0 END) AS apps_without_client_id
FROM public.loan_applications;

-- 3) duplicats email (devrait être 0)
SELECT lower(primary_email) AS email, COUNT(*)
FROM public.clients
WHERE primary_email IS NOT NULL
GROUP BY 1
HAVING COUNT(*) > 1;
