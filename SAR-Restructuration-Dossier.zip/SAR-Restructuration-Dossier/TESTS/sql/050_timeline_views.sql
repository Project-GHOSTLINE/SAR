-- Phase 5 tests

SELECT to_regclass('public.vw_client_timeline') AS timeline_view;
SELECT to_regclass('public.vw_client_summary') AS summary_view;

-- Sample: top 20 timeline rows
SELECT * FROM public.vw_client_timeline ORDER BY ts DESC LIMIT 20;

-- Sample: top 20 summaries
SELECT * FROM public.vw_client_summary LIMIT 20;
