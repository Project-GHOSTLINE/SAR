-- 040_create_vopay_objects.sql
-- Phase 4: normalisation VoPay (raw logs -> objets lisibles dossier)

CREATE TABLE IF NOT EXISTS public.vopay_objects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NULL REFERENCES public.clients(id) ON DELETE SET NULL,
  loan_id uuid NULL REFERENCES public.loans(id) ON DELETE SET NULL,
  account_id uuid NULL,
  object_type text NOT NULL,      -- transfer|verification|payout|...
  vopay_id text NOT NULL,
  status text NULL,
  amount numeric(12,2) NULL,
  currency text NULL DEFAULT 'CAD',
  counterparty jsonb NOT NULL DEFAULT '{}'::jsonb,
  occurred_at timestamptz NULL,
  raw_log_id uuid NULL,           -- FK optionnel vers vopay_webhook_logs.id
  created_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE UNIQUE INDEX IF NOT EXISTS vopay_objects_unique
  ON public.vopay_objects (object_type, vopay_id);

CREATE INDEX IF NOT EXISTS vopay_objects_client_id_idx ON public.vopay_objects(client_id);
CREATE INDEX IF NOT EXISTS vopay_objects_occurred_at_idx ON public.vopay_objects(occurred_at);
