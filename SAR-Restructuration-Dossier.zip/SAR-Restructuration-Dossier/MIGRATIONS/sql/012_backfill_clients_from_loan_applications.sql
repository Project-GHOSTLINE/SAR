-- 012_backfill_clients_from_loan_applications.sql
-- Phase 1: créer clients depuis loan_applications et relier client_id.
-- Assumption: loan_applications contient email/tel/prenom/nom (adapter les colonnes).

-- ⚠️ ADAPTER ICI les colonnes:
-- - email_col
-- - phone_col
-- - first_name_col
-- - last_name_col

-- Exemple supposé:
--   loan_applications.email, loan_applications.phone, loan_applications.first_name, loan_applications.last_name

WITH src AS (
  SELECT
    la.id AS application_id,
    NULLIF(trim(la.email), '') AS email,
    NULLIF(trim(la.phone), '') AS phone,
    NULLIF(trim(la.first_name), '') AS first_name,
    NULLIF(trim(la.last_name), '') AS last_name
  FROM public.loan_applications la
),
ins AS (
  INSERT INTO public.clients (primary_email, primary_phone, first_name, last_name)
  SELECT DISTINCT
    lower(email) AS primary_email,
    phone AS primary_phone,
    first_name,
    last_name
  FROM src
  WHERE email IS NOT NULL OR phone IS NOT NULL
  ON CONFLICT (lower(primary_email)) DO NOTHING
  RETURNING id, primary_email
)
UPDATE public.loan_applications la
SET client_id = c.id
FROM public.clients c
WHERE la.client_id IS NULL
  AND (
    (la.email IS NOT NULL AND lower(la.email) = lower(c.primary_email))
    OR (la.phone IS NOT NULL AND la.phone = c.primary_phone)
  );
