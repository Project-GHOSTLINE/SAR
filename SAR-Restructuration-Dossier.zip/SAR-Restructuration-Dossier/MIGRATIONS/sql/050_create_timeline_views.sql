-- 050_create_timeline_views.sql
-- Phase 5: vues "dossier médical"

-- 1) Timeline (UNION ALL)
CREATE OR REPLACE VIEW public.vw_client_timeline AS
SELECT
  c.client_id,
  c.created_at AS ts,
  'COMMUNICATION'::text AS kind,
  c.channel AS subtype,
  c.direction AS direction,
  c.subject AS title,
  left(COALESCE(c.body_text,''), 240) AS summary,
  jsonb_build_object('communication_id', c.id, 'provider', c.provider, 'provider_message_id', c.provider_message_id) AS ref
FROM public.communications c

UNION ALL
SELECT
  pe.loan_id::uuid AS client_id,  -- placeholder, fix in next block if you want client_id
  pe.created_at AS ts,
  'PAYMENT_EVENT'::text AS kind,
  pe.event_type AS subtype,
  NULL::text AS direction,
  pe.event_type AS title,
  COALESCE(pe.payload->>'note','') AS summary,
  jsonb_build_object('payment_event_id', pe.id, 'loan_id', pe.loan_id, 'amount', pe.amount) AS ref
FROM public.payment_events pe;

-- NOTE: la 2e partie nécessite idéalement client_id: on recommande plutôt de JOIN loans.
-- Si tu veux corriger immédiatement, remplace le bloc PAYMENT_EVENT par:
-- SELECT l.client_id, pe.created_at, ... FROM payment_events pe JOIN loans l ON l.id=pe.loan_id;

-- 2) Summary KPI (à adapter avec tes tables)
CREATE OR REPLACE VIEW public.vw_client_summary AS
SELECT
  cl.id AS client_id,
  cl.primary_email,
  cl.primary_phone,
  cl.first_name,
  cl.last_name,
  (SELECT COUNT(*) FROM public.loan_applications la WHERE la.client_id = cl.id) AS applications_count,
  (SELECT COUNT(*) FROM public.loans l WHERE l.client_id = cl.id) AS loans_count,
  (SELECT MAX(sent_at) FROM public.communications co WHERE co.client_id = cl.id AND co.direction='outbound') AS last_outbound_contact_at,
  (SELECT MAX(received_at) FROM public.communications co WHERE co.client_id = cl.id AND co.direction='inbound') AS last_inbound_contact_at
FROM public.clients cl;
