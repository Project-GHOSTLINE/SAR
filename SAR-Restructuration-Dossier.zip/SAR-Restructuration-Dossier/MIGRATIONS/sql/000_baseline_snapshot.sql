-- 000_baseline_snapshot.sql
-- Objectif: capturer un état baseline et détecter surprises.
-- À exécuter avant tout changement.

-- 1) Liste tables/tailles (approx)
SELECT schemaname, relname, n_live_tup
FROM pg_stat_user_tables
ORDER BY n_live_tup DESC;

-- 2) Vérifier RLS activé / policies (aperçu)
SELECT n.nspname AS schema, c.relname AS table, c.relrowsecurity AS rls_enabled
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relkind='r' AND n.nspname='public'
ORDER BY c.relname;

-- 3) Baseline: quelques compteurs utiles (adapter les noms si besoin)
-- NOTE: commente/décommente selon tes tables réelles
-- SELECT COUNT(*) AS loan_applications FROM public.loan_applications;
-- SELECT COUNT(*) AS client_accounts FROM public.client_accounts;
