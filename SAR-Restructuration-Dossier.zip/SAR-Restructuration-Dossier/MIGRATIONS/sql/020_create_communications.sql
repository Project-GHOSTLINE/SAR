-- 020_create_communications.sql
-- Phase 2: communications unifiées (email/sms/support/internal)

CREATE TABLE IF NOT EXISTS public.communications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  application_id uuid NULL,
  account_id uuid NULL,
  loan_id uuid NULL,

  channel text NOT NULL,          -- email|sms|support|internal
  direction text NOT NULL,        -- inbound|outbound
  thread_key text NULL,

  from_addr text NULL,
  to_addrs jsonb NULL,
  cc_addrs jsonb NULL,

  subject text NULL,
  body_text text NULL,            -- ou body_ref si tu stockes en Storage
  provider text NULL,             -- m365|twilio|brevo|...
  provider_message_id text NULL,  -- Message-ID / SID
  status text NOT NULL DEFAULT 'stored',

  received_at timestamptz NULL,
  sent_at timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS communications_client_id_idx ON public.communications(client_id);
CREATE INDEX IF NOT EXISTS communications_thread_key_idx ON public.communications(thread_key);
CREATE INDEX IF NOT EXISTS communications_sent_at_idx ON public.communications(sent_at);
CREATE INDEX IF NOT EXISTS communications_received_at_idx ON public.communications(received_at);

CREATE TABLE IF NOT EXISTS public.communication_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  communication_id uuid NOT NULL REFERENCES public.communications(id) ON DELETE CASCADE,
  storage_path text NOT NULL,
  filename text NULL,
  mime_type text NULL,
  size_bytes bigint NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS comm_attach_comm_id_idx ON public.communication_attachments(communication_id);
