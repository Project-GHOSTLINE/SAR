-- 021_migrate_emails_envoyes_to_communications.sql
-- Phase 2: migration legacy outbound si `emails_envoyes` existe.
-- ⚠️ Adapter colonnes: emails_envoyes(to_email, subject, body, sent_at, client_email?) etc.

-- Exemple minimal: nécessite un mapping email -> client_id.
INSERT INTO public.communications (
  client_id, channel, direction, from_addr, to_addrs, subject, body_text, provider, sent_at, metadata
)
SELECT
  c.id AS client_id,
  'email' AS channel,
  'outbound' AS direction,
  ee.from_email AS from_addr,
  jsonb_build_array(ee.to_email) AS to_addrs,
  ee.subject,
  ee.body,
  COALESCE(ee.provider, 'legacy') AS provider,
  ee.sent_at,
  jsonb_build_object('legacy_table','emails_envoyes','legacy_id',ee.id)
FROM public.emails_envoyes ee
JOIN public.clients c
  ON lower(c.primary_email) = lower(ee.to_email) OR lower(c.primary_email) = lower(ee.client_email)
WHERE ee.sent_at IS NOT NULL;

-- NOTE: si tu veux idempotence, ajoute une contrainte unique sur (provider, provider_message_id) ou legacy_id.
