#!/bin/bash

echo "============================================"
echo "🔍 VÉRIFICATION IBV CRAWLER V2"
echo "============================================"
echo ""

cd /Users/xunit/Desktop/IBV-Crawler-V2-CLEAN

# Vérifier que tous les fichiers existent
echo "📁 Fichiers requis..."
FILES=(
  "manifest.json"
  "content-script.js"
  "styles.css"
  "icon.svg"
  "popup.html"
  "popup.js"
)

ALL_PRESENT=true
for file in "${FILES[@]}"; do
  if [ -f "$file" ]; then
    echo "  ✅ $file"
  else
    echo "  ❌ $file MANQUANT!"
    ALL_PRESENT=false
  fi
done

if [ "$ALL_PRESENT" = false ]; then
  echo ""
  echo "❌ ERREUR: Fichiers manquants!"
  exit 1
fi

echo ""
echo "🔧 Syntaxe JavaScript..."
node -c content-script.js 2>&1
if [ $? -eq 0 ]; then
  echo "  ✅ content-script.js"
else
  echo "  ❌ content-script.js: ERREUR!"
  exit 1
fi

node -c popup.js 2>&1
if [ $? -eq 0 ]; then
  echo "  ✅ popup.js"
else
  echo "  ❌ popup.js: ERREUR!"
  exit 1
fi

echo ""
echo "📋 Syntaxe JSON..."
python3 -m json.tool manifest.json > /dev/null 2>&1
if [ $? -eq 0 ]; then
  echo "  ✅ manifest.json"
else
  echo "  ❌ manifest.json: ERREUR!"
  exit 1
fi

echo ""
echo "🔍 Patterns dans manifest.json..."
cat manifest.json | grep -A 10 "content_scripts" | grep "matches" -A 5 | grep -E "(inverite.com|view)"
echo "  ✅ Patterns configurés"

echo ""
echo "📊 Tailles des fichiers..."
ls -lh *.js *.json *.css *.svg *.html 2>/dev/null | awk '{print "  " $9 ": " $5}'

echo ""
echo "🧪 Test API Inverite..."
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X GET \
  "https://www.inverite.com/api/v2/fetch/238DAD06-C8C6-4BE9-8954-E23E936DD5D9" \
  -H "Auth: 09ccfeec2e0c6de5eca68f2165cb81d2947")

if [ "$HTTP_CODE" = "200" ]; then
  echo "  ✅ API Inverite: 200 OK"
else
  echo "  ⚠️  API Inverite: $HTTP_CODE"
fi

echo ""
echo "🧪 Test API SAR..."
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X POST \
  "https://admin.solutionargentrapide.ca/api/admin/client-analysis" \
  -H "Content-Type: application/json" \
  -d '{}')

if [ "$HTTP_CODE" = "401" ]; then
  echo "  ✅ API SAR: 401 (normal sans token)"
else
  echo "  ⚠️  API SAR: $HTTP_CODE"
fi

echo ""
echo "============================================"
echo "✅ TOUTES LES VÉRIFICATIONS RÉUSSIES!"
echo "============================================"
echo ""
echo "📋 PROCHAINES ÉTAPES:"
echo ""
echo "1. Charger l'extension:"
echo "   chrome://extensions/ → Charger non empaquetée"
echo "   → Sélectionner: /Users/xunit/Desktop/IBV-Crawler-V2-CLEAN"
echo ""
echo "2. Configurer le token:"
echo "   → Cliquer sur l'icône de l'extension"
echo "   → Coller le token SAR"
echo "   → Sauvegarder"
echo ""
echo "3. Tester sur une page Inverite:"
echo "   → https://www.inverite.com/merchant/request/view/[GUID]"
echo "   → F12 → Console"
echo "   → Cliquer 'Analyser le client'"
echo ""
echo "============================================"
