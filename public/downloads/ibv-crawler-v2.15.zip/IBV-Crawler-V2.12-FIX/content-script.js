// ============================================
// IBV CRAWLER V2.05 - TEST & CONSOLE
// ============================================

// ============================================
// CAPTURER LES LOGS DE LA CONSOLE
// ============================================
const consoleLogs = [];
const originalLog = console.log;
const originalError = console.error;
const originalWarn = console.warn;

console.log = function(...args) {
  consoleLogs.push({ type: 'log', time: new Date().toISOString(), args: args });
  originalLog.apply(console, args);
};

console.error = function(...args) {
  consoleLogs.push({ type: 'error', time: new Date().toISOString(), args: args });
  originalError.apply(console, args);
};

console.warn = function(...args) {
  consoleLogs.push({ type: 'warn', time: new Date().toISOString(), args: args });
  originalWarn.apply(console, args);
};

console.log('🚀 IBV Crawler V2.12 - SAR PRODUCTION - Démarrage');

// ============================================
// CONFIGURATION
// ============================================
const CONFIG = {
  INVERITE_API_KEY: '09ccfeec2e0c6de5eca68f2165cb81d2947',
  INVERITE_API_URL: 'https://www.inverite.com/api/v2/fetch',

  // SAR API - PRODUCTION endpoint
  SAR_API_URL: 'https://admin.solutionargentrapide.ca/api/admin/client-analysis',
  SAR_REPORT_URL: 'https://admin.solutionargentrapide.ca/analyse',

  // Supabase - Fallback uniquement
  SUPABASE_URL: 'https://dllyzfuqjzuhvshrlmuq.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRsbHl6ZnVxanp1aHZzaHJsbXVxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU5OTU5ODEsImV4cCI6MjA4MTU3MTk4MX0.xskVblRlKdbTST1Mdgz76oR7N2rDq8ZOUgaN-f_TTM4'
};

// ============================================
// 1. DÉTECTER LE TYPE DE SITE
// ============================================
function detectSiteType() {
  const hostname = window.location.hostname;
  const pathname = window.location.pathname;

  console.log('🌐 URL actuelle:', window.location.href);
  console.log('🌐 Hostname:', hostname);
  console.log('🌐 Pathname:', pathname);

  // Vérifier Inverite
  if (hostname.includes('inverite.com')) {
    const inveriteGuid = pathname.match(/\/view\/([A-Fa-f0-9-]+)/);
    if (inveriteGuid) {
      return {
        type: 'inverite',
        guid: inveriteGuid[1]
      };
    }
  }

  // Vérifier Flinks
  // URL Format: https://dashboard.flinks.com/en/[ORG-ID]/insights/requests/[REQUEST-ID]/banking
  // Ou: https://dashboard.flinks.com/insights/requests/[REQUEST-ID]
  if (hostname.includes('flinks') || hostname.includes('fin.ag')) {
    console.log('🔍 Détection Flinks - hostname:', hostname);
    console.log('🔍 Détection Flinks - pathname:', pathname);

    // Regex plus flexible pour capturer l'ID (majuscules, minuscules, chiffres, tirets)
    const flinksRequestId = pathname.match(/\/requests\/([A-Za-z0-9-]+)/);

    if (flinksRequestId) {
      console.log('✅ Request ID trouvé:', flinksRequestId[1]);
      return {
        type: 'flinks',
        guid: flinksRequestId[1], // Request ID comme identifiant unique
        requestId: flinksRequestId[1]
      };
    } else {
      console.log('❌ Pas de Request ID trouvé dans le pathname');
      console.log('   Format attendu: /requests/[REQUEST-ID]');
    }
  }

  return null;
}

const siteInfo = detectSiteType();

if (!siteInfo) {
  console.log('❌ Site non supporté - Extension inactive');
} else {
  console.log(`✅ Site détecté: ${siteInfo.type.toUpperCase()}`);
  if (siteInfo.guid) {
    console.log(`   GUID: ${siteInfo.guid.substring(0, 12)}...`);
  }
  initExtension(siteInfo);
}

// ============================================
// 2. INITIALISER L'EXTENSION
// ============================================
function initExtension(siteInfo) {
  // Créer un conteneur pour les boutons
  const container = document.createElement('div');
  container.id = 'ibv-buttons-container';
  container.style.cssText = 'position: fixed; top: 120px; right: 20px; z-index: 999999; display: flex; flex-direction: column; gap: 10px;';

  // BOUTON 1: Analyser le client (principal)
  const analyzeButton = document.createElement('button');
  analyzeButton.id = 'ibv-analyze-btn';
  analyzeButton.className = 'ibv-analyze-button';
  const buttonText = siteInfo.type === 'inverite' ? 'Analyser le client (Inverite)' : 'Analyser le client (Flinks)';
  analyzeButton.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
      <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
      <line x1="12" y1="22.08" x2="12" y2="12"></line>
    </svg>
    <span>${buttonText}</span>
  `;
  analyzeButton.addEventListener('click', (event) => handleAnalyzeClick(event, siteInfo));
  container.appendChild(analyzeButton);

  // BOUTON 2: Test OpenBox (Flinks seulement)
  if (siteInfo.type === 'flinks') {
    const testButton = document.createElement('button');
    testButton.id = 'ibv-test-btn';
    testButton.className = 'ibv-analyze-button';
    testButton.style.backgroundColor = '#f59e0b';
    testButton.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M9 11l3 3L22 4"></path>
        <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
      </svg>
      <span>Test OpenBox</span>
    `;
    testButton.addEventListener('click', () => handleTestOpenBox(testButton));
    container.appendChild(testButton);
  }

  // BOUTON 3: Copier Console
  const copyButton = document.createElement('button');
  copyButton.id = 'ibv-copy-btn';
  copyButton.className = 'ibv-analyze-button';
  copyButton.style.backgroundColor = '#8b5cf6';
  copyButton.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
    </svg>
    <span>Copier Console</span>
  `;
  copyButton.addEventListener('click', () => handleCopyConsole(copyButton));
  container.appendChild(copyButton);

  // Ajouter le conteneur au DOM
  document.body.appendChild(container);
  console.log('✅ Boutons injectés:', container.children.length);
}

// ============================================
// 3. HANDLERS DES BOUTONS
// ============================================
async function handleAnalyzeClick(event, siteInfo) {
  const button = event.currentTarget;
  console.log(`🎯 Click sur le bouton - Type: ${siteInfo.type}`);

  if (siteInfo.type === 'inverite') {
    await handleInveriteAnalysis(button, siteInfo.guid);
  } else if (siteInfo.type === 'flinks') {
    await handleFlinksAnalysis(button, siteInfo);
  }
}

// Test OpenBox - Tester l'ouverture des comptes
async function handleTestOpenBox(button) {
  const originalContent = button.innerHTML;

  try {
    button.disabled = true;
    button.innerHTML = '<span>Test en cours...</span>';

    console.log('🧪 TEST OPENBOX - Démarrage');
    await expandAllAccounts();

    button.innerHTML = '<span>✅ Test OK!</span>';
    button.style.backgroundColor = '#10b981';

    setTimeout(() => {
      button.disabled = false;
      button.innerHTML = originalContent;
      button.style.backgroundColor = '#f59e0b';
    }, 2000);

  } catch (error) {
    console.error('❌ Erreur Test OpenBox:', error);
    button.innerHTML = '<span>❌ Erreur</span>';
    setTimeout(() => {
      button.disabled = false;
      button.innerHTML = originalContent;
    }, 2000);
  }
}

// Copier Console - Copier tous les logs
function handleCopyConsole(button) {
  const originalContent = button.innerHTML;

  try {
    console.log('📋 Copie des logs de la console...');

    // Formater les logs
    let logText = '=== LOGS CONSOLE IBV CRAWLER ===\n\n';

    consoleLogs.forEach((log, i) => {
      const timestamp = new Date(log.time).toLocaleTimeString();
      const type = log.type.toUpperCase();
      const args = log.args.map(arg => {
        if (typeof arg === 'object') {
          return JSON.stringify(arg, null, 2);
        }
        return String(arg);
      }).join(' ');

      logText += `[${timestamp}] ${type}: ${args}\n`;
    });

    logText += `\n=== TOTAL: ${consoleLogs.length} logs ===`;

    // Copier dans le presse-papiers
    navigator.clipboard.writeText(logText).then(() => {
      console.log(`✅ ${consoleLogs.length} logs copiés dans le presse-papiers!`);
      button.innerHTML = '<span>✅ Copié!</span>';
      button.style.backgroundColor = '#10b981';

      setTimeout(() => {
        button.innerHTML = originalContent;
        button.style.backgroundColor = '#8b5cf6';
      }, 2000);
    });

  } catch (error) {
    console.error('❌ Erreur copie console:', error);
    button.innerHTML = '<span>❌ Erreur</span>';
    setTimeout(() => {
      button.innerHTML = originalContent;
    }, 2000);
  }
}

// ============================================
// 4. INVERITE - LOGIQUE EXISTANTE
// ============================================
async function handleInveriteAnalysis(button, guid) {
  const originalContent = button.innerHTML;

  // Désactiver le bouton
  button.disabled = true;
  button.innerHTML = `
    <div class="spinner"></div>
    <span>Analyse en cours...</span>
  `;

  try {
    // Étape 1: Récupérer données Inverite
    const inveriteData = await fetchInveriteData(guid);

    // Étape 2: Extraire les infos
    const clientData = extractInveriteClientInfo(inveriteData, guid);
    console.log('📊 Client:', clientData.client_name);
    console.log('   Comptes:', clientData.total_accounts);
    console.log('   Balance:', clientData.total_balance.toFixed(2), '$');
    console.log('   Transactions:', clientData.total_transactions);

    // Étape 3: Envoyer à SAR API
    const result = await sendToSAR(clientData);

    // Étape 4: Afficher le succès et le lien
    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
        <polyline points="22 4 12 14.01 9 11.01"></polyline>
      </svg>
      <span>✅ Enregistré! Ouverture...</span>
    `;

    console.log('🚀 Ouverture page analyse dans nouvel onglet');
    console.log(`   URL: ${CONFIG.SAR_REPORT_URL}?id=${result.id}`);

    setTimeout(() => {
      window.open(`${CONFIG.SAR_REPORT_URL}?id=${result.id}`, '_blank');
      button.disabled = false;
      button.innerHTML = originalContent;
    }, 1000);

  } catch (error) {
    console.error('❌ ERREUR:', error);

    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>
      <span>Erreur: ${error.message}</span>
    `;

    setTimeout(() => {
      button.disabled = false;
      button.innerHTML = originalContent;
    }, 3000);
  }
}

async function fetchInveriteData(guid) {
  console.log('📡 Récupération données Inverite...');

  try {
    const apiUrl = `${CONFIG.INVERITE_API_URL}/${guid}`;
    console.log('   URL:', apiUrl);

    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Auth': CONFIG.INVERITE_API_KEY,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Inverite API: ${response.status}`);
    }

    const data = await response.json();
    console.log('✅ Données Inverite reçues:', data.name || 'Client');
    return data;

  } catch (error) {
    console.error('❌ Erreur Inverite API:', error);
    throw error;
  }
}

function extractInveriteClientInfo(data, guid) {
  const clientName = data.name || 'Client Inconnu';

  let totalAccounts = 0;
  let totalBalance = 0;
  let totalTransactions = 0;

  if (data.accounts && Array.isArray(data.accounts)) {
    totalAccounts = data.accounts.length;

    data.accounts.forEach(account => {
      if (account.current_balance) {
        totalBalance += parseFloat(account.current_balance) || 0;
      }
      if (account.transactions && Array.isArray(account.transactions)) {
        totalTransactions += account.transactions.length;
      }
    });
  }

  return {
    client_name: clientName,
    source: 'inverite',
    inverite_guid: guid,
    raw_data: data,
    total_accounts: totalAccounts,
    total_balance: totalBalance,
    total_transactions: totalTransactions
  };
}

// ============================================
// 5. FLINKS - EXTRACTION AUTOMATIQUE
// ============================================
async function handleFlinksAnalysis(button, siteInfo) {
  const originalContent = button.innerHTML;

  button.disabled = true;
  button.innerHTML = `
    <div class="spinner"></div>
    <span>Ouverture des comptes...</span>
  `;

  try {
    console.log('🔵 FLINKS - Analyse démarrée');
    console.log('   Request ID:', siteInfo.requestId);
    console.log('   URL:', window.location.href);

    // ÉTAPE 1: Ouvrir tous les comptes automatiquement
    button.innerHTML = `
      <div class="spinner"></div>
      <span>Ouverture automatique des comptes...</span>
    `;

    await expandAllAccounts();

    // ÉTAPE 2: Extraire les données du DOM
    button.innerHTML = `
      <div class="spinner"></div>
      <span>Extraction des données...</span>
    `;

    const clientData = await extractFlinksData(siteInfo.requestId);

    console.log('📊 Client:', clientData.client_name);
    console.log('   Comptes:', clientData.total_accounts);
    console.log('   Balance:', clientData.total_balance.toFixed(2), '$');
    console.log('   Transactions:', clientData.total_transactions);

    // ÉTAPE 3: Envoyer à SAR API
    const result = await sendToSAR(clientData);

    // ÉTAPE 4: Afficher le succès et le lien
    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
        <polyline points="22 4 12 14.01 9 11.01"></polyline>
      </svg>
      <span>✅ Enregistré! Ouverture...</span>
    `;

    console.log('🚀 Ouverture page analyse dans nouvel onglet');
    console.log(`   URL: ${CONFIG.SAR_REPORT_URL}?id=${result.id}`);

    setTimeout(() => {
      window.open(`${CONFIG.SAR_REPORT_URL}?id=${result.id}`, '_blank');
      button.disabled = false;
      button.innerHTML = originalContent;
    }, 1000);

  } catch (error) {
    console.error('❌ ERREUR FLINKS:', error);

    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>
      <span>Erreur: ${error.message}</span>
    `;

    setTimeout(() => {
      button.disabled = false;
      button.innerHTML = originalContent;
    }, 3000);
  }
}

// Ouvrir tous les comptes automatiquement
async function expandAllAccounts() {
  console.log('🔓 Ouverture automatique de tous les comptes...');

  // Flinks utilise Font Awesome pour les chevrons
  const chevronIcons = document.querySelectorAll('button i[class*="fa-angle"]');
  const accountButtons = Array.from(chevronIcons).map(icon => icon.closest('button'));

  console.log(`   Trouvé ${accountButtons.length} comptes à ouvrir`);

  for (let i = 0; i < accountButtons.length; i++) {
    const button = accountButtons[i];
    const icon = button.querySelector('i');
    console.log(`   Ouverture compte ${i + 1}/${accountButtons.length}... (${icon.className})`);

    // Cliquer sur le bouton
    button.click();

    // Attendre 800ms pour que les transactions se chargent
    await sleep(800);
  }

  // Chercher les boutons "EXPAND TABLE" pour voir plus de transactions
  const expandButtons = Array.from(document.querySelectorAll('button')).filter(btn =>
    btn.textContent.includes('EXPAND TABLE') || btn.textContent.includes('Expand Table')
  );

  if (expandButtons.length > 0) {
    console.log(`   Expansion des tableaux (${expandButtons.length})...`);
    for (const btn of expandButtons) {
      btn.click();
      await sleep(300);
    }
  }

  console.log('✅ Tous les comptes sont ouverts');
}

// Extraire les données depuis le DOM Flinks
async function extractFlinksData(requestId) {
  console.log('📊 Extraction des données Flinks depuis le DOM...');

  // Helper: Chercher une valeur depuis un label (version améliorée)
  const findValue = (parent, labelText) => {
    const allElements = Array.from(parent.querySelectorAll('*'));

    // Trouver l'élément qui contient EXACTEMENT le label
    for (let i = 0; i < allElements.length; i++) {
      const elem = allElements[i];
      const text = elem.textContent.trim();

      // Si c'est exactement le label
      if (text === labelText) {
        // Chercher le prochain élément avec du contenu
        for (let j = i + 1; j < allElements.length; j++) {
          const nextElem = allElements[j];
          const nextText = nextElem.textContent.trim();

          // Ignorer les éléments vides ou qui contiennent le label
          if (nextText && nextText !== labelText && !nextText.includes(labelText)) {
            // Si c'est multi-ligne (ex: Request Date/Time), prendre tout le contenu
            return nextText;
          }
        }
      }
    }
    return '';
  };

  // Extraire toutes les informations client
  let clientInfo = {
    name: '',
    email: '',
    address: '',
    institution: '',
    employer: '',
    loginId: '',
    requestDate: '',
    requestStatus: '',
    daysDetected: ''
  };

  const headings = Array.from(document.querySelectorAll('h2, h3, div'));

  // Customer Information
  for (const h of headings) {
    if (h.textContent.includes('Customer Information')) {
      const parent = h.closest('div');
      if (parent) {
        clientInfo.name = findValue(parent, 'Name') || 'Client Inconnu';
        clientInfo.email = findValue(parent, 'Email');
        clientInfo.address = findValue(parent, 'Address');
        clientInfo.institution = findValue(parent, 'Financial Institution');
        clientInfo.employer = findValue(parent, 'Employer Name');
        clientInfo.loginId = findValue(parent, 'Login ID');
      }
      break;
    }
  }

  // Request Information
  for (const h of headings) {
    if (h.textContent.includes('Request Information')) {
      const parent = h.closest('div');
      if (parent) {
        clientInfo.requestDate = findValue(parent, 'Request Date/Time');
        clientInfo.requestStatus = findValue(parent, 'Request Status');
        clientInfo.daysDetected = findValue(parent, 'Days Detected');
      }
      break;
    }
  }

  console.log('   Client:', clientInfo.name);

  // Extraire tous les comptes depuis le tableau principal
  const accounts = [];

  // Chercher toutes les rangées (seulement <td>, ignorer <th>)
  const allRows = document.querySelectorAll('tr');

  console.log(`   Analyse de ${allRows.length} rangées...`);

  let currentAccount = null;

  for (const row of allRows) {
    // Ignorer les headers (th)
    const headers = row.querySelectorAll('th');
    if (headers.length > 0) {
      continue; // Skip header rows
    }

    const cells = row.querySelectorAll('td');
    if (cells.length === 0) continue;

    const firstCell = cells[0]?.textContent?.trim();

    // Détection d'une ligne de compte (8 colonnes avec data-account-id)
    if (cells.length === 8) {
      const accountName = cells[1]?.textContent?.trim();
      const accountNumber = cells[2]?.textContent?.trim();
      const accountType = cells[3]?.textContent?.trim();
      const balance = cells[4]?.textContent?.trim();

      // Vérifier que c'est bien un compte (nom et numéro non vides)
      if (accountName && accountNumber && accountName !== 'Account Name') {
        // Sauvegarder le compte précédent
        if (currentAccount) {
          accounts.push(currentAccount);
        }

        // Nouveau compte
        currentAccount = {
          title: accountName,
          account_number: accountNumber,
          type: accountType || 'Unknown',
          current_balance: parseFloat(balance?.replace(/[^0-9.-]/g, '')) || 0,
          transactions: []
        };
      }
    }
    // Détection d'une ligne de transaction (5 colonnes, commence par date YYYY-MM-DD)
    else if (cells.length === 5 && firstCell && firstCell.match(/^\d{4}-\d{2}-\d{2}$/)) {
      // C'est une transaction
      if (currentAccount) {
        const transaction = {
          date: cells[0]?.textContent?.trim(),
          description: cells[1]?.textContent?.trim(),
          withdrawals: cells[2]?.textContent?.trim() || '',
          deposits: cells[3]?.textContent?.trim() || '',
          balance: cells[4]?.textContent?.trim() || ''
        };
        currentAccount.transactions.push(transaction);
      }
    }
  }

  // Ajouter le dernier compte
  if (currentAccount) {
    accounts.push(currentAccount);
  }

  console.log(`   ✅ ${accounts.length} comptes extraits`);

  // Calculer les totaux
  const totalAccounts = accounts.length;
  const totalBalance = accounts.reduce((sum, acc) => sum + (acc.current_balance || 0), 0);
  const totalTransactions = accounts.reduce((sum, acc) => sum + (acc.transactions?.length || 0), 0);

  console.log('   Comptes:', totalAccounts);
  console.log('   Balance totale:', totalBalance.toFixed(2), '$');
  console.log('   Transactions:', totalTransactions);

  return {
    client_name: clientInfo.name,
    source: 'flinks',
    inverite_guid: requestId, // Utiliser inverite_guid pour Flinks aussi
    raw_data: {
      accounts,
      requestId,
      clientInfo // Ajouter toutes les infos client
    },
    total_accounts: totalAccounts,
    total_balance: totalBalance,
    total_transactions: totalTransactions
  };
}

// Helper: Sleep
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================
// 6. SAR API - COMMUN AUX DEUX
// ============================================
async function sendToSAR(clientData) {
  console.log('📤 Envoi à SAR API...');

  try {
    // Préparer les données pour l'API SAR
    const dataToSave = {
      client_name: clientData.client_name,
      source: clientData.source,
      inverite_guid: clientData.inverite_guid,
      raw_data: clientData.raw_data
    };

    console.log('   Envoi des données:', {
      client_name: dataToSave.client_name,
      source: dataToSave.source,
      accounts: clientData.total_accounts,
      balance: clientData.total_balance
    });

    // Envoyer à l'API SAR (pas besoin d'authentification - l'API SAR gère ça)
    const response = await fetch(CONFIG.SAR_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}` // Token pour authentification
      },
      body: JSON.stringify(dataToSave)
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('   Erreur SAR API:', errorData);
      throw new Error(`SAR API Error: ${response.status} - ${errorData}`);
    }

    const result = await response.json();
    console.log('✅ Données enregistrées dans SAR!', result);

    return result.data;

  } catch (error) {
    console.error('❌ Erreur SAR API:', error);
    throw error;
  }
}

console.log('✅ IBV Crawler V2.12 - SAR PRODUCTION - Prêt (Flinks + Inverite)');
