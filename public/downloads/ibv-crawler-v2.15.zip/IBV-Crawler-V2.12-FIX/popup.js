// ============================================
// IBV CRAWLER V2 - POPUP CONFIGURATION
// ============================================

const tokenInput = document.getElementById('token');
const saveBtn = document.getElementById('saveBtn');
const testBtn = document.getElementById('testBtn');
const clearBtn = document.getElementById('clearBtn');
const statusDiv = document.getElementById('status');

const SAR_API_URL = 'https://admin.solutionargentrapide.ca/api/admin/client-analysis';

// ============================================
// CHARGER LE TOKEN EXISTANT
// ============================================
chrome.storage.sync.get(['sarToken'], (result) => {
  if (result.sarToken) {
    tokenInput.value = result.sarToken;
  }
});

// ============================================
// SAUVEGARDER LE TOKEN
// ============================================
saveBtn.addEventListener('click', () => {
  const token = tokenInput.value.trim();

  if (!token) {
    showStatus('❌ Token vide', 'error');
    return;
  }

  chrome.storage.sync.set({ sarToken: token }, () => {
    showStatus('✅ Token sauvegardé avec succès!', 'success');

    // Notifier le content script
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'tokenUpdated',
          token: token
        }).catch(() => {
          // Ignore si pas de content script
        });
      }
    });
  });
});

// ============================================
// TESTER LE TOKEN
// ============================================
testBtn.addEventListener('click', async () => {
  const token = tokenInput.value.trim();

  if (!token) {
    showStatus('❌ Token vide', 'error');
    return;
  }

  showStatus('🔄 Test en cours...', 'success');
  testBtn.disabled = true;

  try {
    const response = await fetch(SAR_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        client_name: 'TEST',
        source: 'test',
        raw_data: {}
      })
    });

    const data = await response.json();

    if (response.status === 400 && data.error?.includes('client_name')) {
      // Si l'erreur est juste sur les données manquantes, le token est valide
      showStatus('✅ Token valide!', 'success');
    } else if (response.status === 401) {
      showStatus('❌ Token invalide ou expiré', 'error');
    } else if (response.ok) {
      showStatus('✅ Token valide!', 'success');
    } else {
      showStatus('⚠️ Erreur: ' + (data.error || response.status), 'error');
    }

  } catch (error) {
    showStatus('❌ Erreur réseau: ' + error.message, 'error');
  } finally {
    testBtn.disabled = false;
  }
});

// ============================================
// EFFACER LE TOKEN
// ============================================
clearBtn.addEventListener('click', () => {
  if (confirm('Effacer le token sauvegardé?')) {
    chrome.storage.sync.remove('sarToken', () => {
      tokenInput.value = '';
      showStatus('🗑️ Token effacé', 'success');

      // Notifier le content script
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, {
            action: 'tokenUpdated',
            token: null
          }).catch(() => {
            // Ignore
          });
        }
      });
    });
  }
});

// ============================================
// AFFICHER STATUS
// ============================================
function showStatus(message, type) {
  statusDiv.textContent = message;
  statusDiv.className = 'status ' + type;
  statusDiv.style.display = 'block';

  setTimeout(() => {
    statusDiv.style.display = 'none';
  }, 3000);
}

// ============================================
// RACCOURCI ENTER
// ============================================
tokenInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    saveBtn.click();
  }
});
