// ============================================
// IBV CRAWLER V2 - CLEAN VERSION
// ============================================

console.log('🚀 IBV Crawler V2 - Démarrage');

// ============================================
// CONFIGURATION
// ============================================
const CONFIG = {
  INVERITE_API_KEY: '09ccfeec2e0c6de5eca68f2165cb81d2947',
  INVERITE_API_URL: 'https://www.inverite.com/api/v2/fetch',

  // Supabase - Direct connection (pas besoin de token compliqué!)
  SUPABASE_URL: 'https://dllyzfuqjzuhvshrlmuq.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRsbHl6ZnVxanp1aHZzaHJsbXVxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU5OTU5ODEsImV4cCI6MjA4MTU3MTk4MX0.xskVblRlKdbTST1Mdgz76oR7N2rDq8ZOUgaN-f_TTM4'
};

// ============================================
// 2. DÉTECTER LE GUID DANS L'URL
// ============================================
function getGuidFromUrl() {
  const match = window.location.pathname.match(/\/view\/([A-Fa-f0-9-]+)/);
  return match ? match[1] : null;
}

const guid = getGuidFromUrl();

if (!guid) {
  console.log('❌ Pas de GUID dans URL - Extension inactive');
} else {
  console.log('✅ GUID détecté:', guid.substring(0, 12) + '...');
  initExtension();
}

// ============================================
// 3. INITIALISER L'EXTENSION
// ============================================
function initExtension() {
  // Créer le bouton
  const button = document.createElement('button');
  button.id = 'ibv-analyze-btn';
  button.className = 'ibv-analyze-button';
  button.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
      <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
      <line x1="12" y1="22.08" x2="12" y2="12"></line>
    </svg>
    <span>Analyser le client</span>
  `;

  // Ajouter au DOM
  document.body.appendChild(button);
  console.log('✅ Bouton injecté');

  // Attacher le handler
  button.addEventListener('click', handleAnalyzeClick);
  console.log('✅ Handler attaché');
}

// ============================================
// 4. RÉCUPÉRER DONNÉES INVERITE
// ============================================
async function fetchInveriteData(guid) {
  console.log('📡 Récupération données Inverite...');

  try {
    // Format qui FONCTIONNE: GET /api/v2/fetch/{guid}
    const apiUrl = `${CONFIG.INVERITE_API_URL}/${guid}`;
    console.log('   URL:', apiUrl);

    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Auth': CONFIG.INVERITE_API_KEY,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Inverite API: ${response.status}`);
    }

    const data = await response.json();
    console.log('✅ Données Inverite reçues:', data.name || 'Client');
    return data;

  } catch (error) {
    console.error('❌ Erreur Inverite API:', error);
    throw error;
  }
}

// ============================================
// 5. EXTRAIRE INFORMATIONS CLIENT
// ============================================
function extractClientInfo(data) {
  const clientName = data.name || 'Client Inconnu';

  // Compter les comptes et calculer balance
  let totalAccounts = 0;
  let totalBalance = 0;
  let totalTransactions = 0;

  if (data.accounts && Array.isArray(data.accounts)) {
    totalAccounts = data.accounts.length;

    data.accounts.forEach(account => {
      if (account.current_balance) {
        totalBalance += parseFloat(account.current_balance) || 0;
      }
      if (account.transactions && Array.isArray(account.transactions)) {
        totalTransactions += account.transactions.length;
      }
    });
  }

  return {
    client_name: clientName,
    source: 'inverite',
    inverite_guid: guid,
    raw_data: data,
    total_accounts: totalAccounts,
    total_balance: totalBalance,
    total_transactions: totalTransactions
  };
}

// ============================================
// 6. ENVOYER À SUPABASE DIRECTEMENT
// ============================================
async function sendToSupabase(clientData) {
  console.log('📤 Envoi à Supabase...');

  try {
    // 1. Vérifier si ce GUID existe déjà
    console.log('   Vérification si GUID existe...');
    const checkResponse = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/client_analyses?inverite_guid=eq.${clientData.inverite_guid}&select=id`, {
      method: 'GET',
      headers: {
        'apikey': CONFIG.SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}`
      }
    });

    const existing = await checkResponse.json();
    const existingId = existing.length > 0 ? existing[0].id : null;

    // 2. Préparer les données
    const id = existingId || crypto.randomUUID();
    const dataToSave = {
      id: id,
      client_name: clientData.client_name,
      source: clientData.source,
      inverite_guid: clientData.inverite_guid,
      raw_data: clientData.raw_data,
      total_accounts: clientData.total_accounts,
      total_balance: clientData.total_balance,
      total_transactions: clientData.total_transactions,
      created_at: existingId ? undefined : new Date().toISOString() // Garder created_at original si update
    };

    // Enlever created_at si c'est un update
    if (existingId) {
      delete dataToSave.created_at;
    }

    console.log(`   ${existingId ? 'Mise à jour' : 'Création'} des données:`, {
      id,
      client_name: dataToSave.client_name,
      accounts: dataToSave.total_accounts,
      balance: dataToSave.total_balance
    });

    // 3. Upsert (POST avec Prefer pour merge)
    const response = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/client_analyses`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': CONFIG.SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}`,
        'Prefer': 'resolution=merge-duplicates,return=representation'
      },
      body: JSON.stringify(dataToSave)
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('   Erreur Supabase:', errorData);
      throw new Error(`Supabase Error: ${response.status} - ${errorData}`);
    }

    const result = await response.json();
    console.log(`✅ Données ${existingId ? 'mises à jour' : 'enregistrées'} dans Supabase! ID:`, id);

    return { id, ...result[0] };

  } catch (error) {
    console.error('❌ Erreur Supabase:', error);
    throw error;
  }
}

// ============================================
// 7. GÉRER LE CLICK
// ============================================
async function handleAnalyzeClick(event) {
  const button = event.currentTarget;
  const originalContent = button.innerHTML;

  console.log('🎯 Click sur le bouton Analyser');

  // Désactiver le bouton
  button.disabled = true;
  button.innerHTML = `
    <div class="spinner"></div>
    <span>Analyse en cours...</span>
  `;

  try {
    // Étape 1: Récupérer données Inverite
    const inveriteData = await fetchInveriteData(guid);

    // Étape 2: Extraire les infos
    const clientData = extractClientInfo(inveriteData);
    console.log('📊 Client:', clientData.client_name);
    console.log('   Comptes:', clientData.total_accounts);
    console.log('   Balance:', clientData.total_balance.toFixed(2), '$');
    console.log('   Transactions:', clientData.total_transactions);

    // Étape 3: Envoyer à Supabase
    const result = await sendToSupabase(clientData);

    // Étape 4: Rediriger
    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
        <polyline points="22 4 12 14.01 9 11.01"></polyline>
      </svg>
      <span>Succès! Redirection...</span>
    `;

    console.log('🚀 Redirection vers /analyse?id=' + result.id);

    setTimeout(() => {
      window.location.href = `http://localhost:3000/analyse?id=${result.id}`;
    }, 1000);

  } catch (error) {
    console.error('❌ ERREUR:', error);

    // Afficher l'erreur
    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>
      <span>Erreur: ${error.message}</span>
    `;

    // Restaurer après 3 secondes
    setTimeout(() => {
      button.disabled = false;
      button.innerHTML = originalContent;
    }, 3000);
  }
}

console.log('✅ IBV Crawler V2 - Prêt');
