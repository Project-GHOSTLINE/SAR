// ============================================
// 🔍 SCRIPT DE DIAGNOSTIC IBV CRAWLER V2
// ============================================
// Copiez-collez ce script dans la console Chrome (F12)
// sur une page Inverite pour diagnostiquer les problèmes

console.log('🔍 === DÉBUT DU DIAGNOSTIC ===');

// ============================================
// 1. VÉRIFIER LE GUID
// ============================================
console.log('\n📋 1. VÉRIFICATION DU GUID');
const urlMatch = window.location.pathname.match(/\/view\/([A-Fa-f0-9-]+)/);
if (urlMatch) {
  const guid = urlMatch[1];
  console.log('✅ GUID détecté:', guid);
} else {
  console.log('❌ PAS DE GUID dans l\'URL');
  console.log('   URL actuelle:', window.location.href);
  console.log('   Format attendu: /view/[GUID]');
}

// ============================================
// 2. VÉRIFIER LE TOKEN
// ============================================
console.log('\n🔑 2. VÉRIFICATION DU TOKEN SAR');
chrome.storage.sync.get(['sarToken'], (result) => {
  if (result.sarToken) {
    console.log('✅ Token configuré');
    console.log('   Longueur:', result.sarToken.length, 'caractères');
    console.log('   Début:', result.sarToken.substring(0, 20) + '...');

    // Vérifier le format JWT
    const parts = result.sarToken.split('.');
    if (parts.length === 3) {
      console.log('✅ Format JWT valide (3 parties)');
    } else {
      console.log('⚠️ Format JWT invalide (devrait avoir 3 parties séparées par des points)');
    }
  } else {
    console.log('❌ Token NON configuré');
    console.log('   Action: Cliquer sur l\'icône de l\'extension et configurer le token');
  }
});

// ============================================
// 3. TESTER L'API INVERITE
// ============================================
console.log('\n📡 3. TEST API INVERITE');
if (urlMatch) {
  const guid = urlMatch[1];
  const apiUrl = `https://www.inverite.com/api/v2/fetch/${guid}`;

  console.log('   URL:', apiUrl);
  console.log('   En cours de test...');

  fetch(apiUrl, {
    method: 'GET',
    headers: {
      'Auth': '09ccfeec2e0c6de5eca68f2165cb81d2947',
      'Content-Type': 'application/json'
    }
  })
  .then(async response => {
    console.log('   Status HTTP:', response.status);

    if (response.ok) {
      const data = await response.json();
      console.log('✅ API Inverite fonctionne!');
      console.log('   Nom client:', data.name || 'N/A');
      console.log('   Nombre de comptes:', data.accounts?.length || 0);
      console.log('   Taille réponse:', JSON.stringify(data).length, 'caractères');
    } else {
      console.log('❌ Erreur API Inverite');
      const errorText = await response.text();
      console.log('   Réponse:', errorText);

      if (response.status === 404) {
        console.log('   💡 Ce GUID n\'existe pas dans Inverite');
        console.log('   💡 Essayez avec un autre dossier client');
      }
    }
  })
  .catch(error => {
    console.log('❌ Erreur réseau Inverite');
    console.log('   Erreur:', error.message);
    console.log('   💡 Vérifiez votre connexion internet');
  });
} else {
  console.log('⏭️  Test ignoré (pas de GUID)');
}

// ============================================
// 4. TESTER L'API SAR
// ============================================
console.log('\n📤 4. TEST API SAR');
chrome.storage.sync.get(['sarToken'], (result) => {
  if (!result.sarToken) {
    console.log('⏭️  Test ignoré (pas de token)');
    return;
  }

  const apiUrl = 'https://admin.solutionargentrapide.ca/api/admin/client-analysis';
  console.log('   URL:', apiUrl);
  console.log('   En cours de test...');

  // Test avec des données minimales
  fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${result.sarToken}`
    },
    body: JSON.stringify({
      client_name: "Test Diagnostic",
      source: "diagnostic",
      raw_data: { test: true }
    })
  })
  .then(async response => {
    console.log('   Status HTTP:', response.status);

    if (response.ok) {
      const data = await response.json();
      console.log('✅ API SAR fonctionne!');
      console.log('   Réponse:', data);

      if (data.success && data.data?.id) {
        console.log('   ID créé:', data.data.id);
        console.log('   💡 L\'extension devrait fonctionner correctement!');
      }
    } else {
      console.log('❌ Erreur API SAR');
      const errorData = await response.json().catch(() => null);

      if (response.status === 401) {
        console.log('   ⚠️ Token invalide ou expiré');
        console.log('   💡 Actions à faire:');
        console.log('      1. Aller sur: https://admin.solutionargentrapide.ca/admin/extension-token');
        console.log('      2. Copier le nouveau token');
        console.log('      3. Cliquer sur l\'icône de l\'extension');
        console.log('      4. Coller le nouveau token');
        console.log('      5. Sauvegarder');
      } else {
        console.log('   Réponse:', errorData || 'Pas de détails');
      }
    }
  })
  .catch(error => {
    console.log('❌ Erreur réseau SAR');
    console.log('   Erreur:', error.message);
    console.log('   💡 L\'API SAR est peut-être hors ligne');
  });
});

// ============================================
// 5. VÉRIFIER L'EXTENSION
// ============================================
console.log('\n🔧 5. VÉRIFICATION DE L\'EXTENSION');

// Vérifier si le bouton existe
setTimeout(() => {
  const button = document.getElementById('ibv-analyze-btn');
  if (button) {
    console.log('✅ Bouton "Analyser" présent dans la page');
    console.log('   Position:', button.getBoundingClientRect());
  } else {
    console.log('❌ Bouton "Analyser" NON trouvé');
    console.log('   💡 Actions à faire:');
    console.log('      1. Aller sur chrome://extensions/');
    console.log('      2. Trouver "IBV Crawler V2"');
    console.log('      3. Cliquer sur 🔄 Recharger');
    console.log('      4. Recharger cette page (Ctrl+R)');
  }

  console.log('\n✅ === DIAGNOSTIC TERMINÉ ===');
  console.log('\n💡 Prochaines étapes:');
  console.log('   1. Lisez les messages ci-dessus');
  console.log('   2. Corrigez les problèmes marqués ❌');
  console.log('   3. Réessayez le bouton "Analyser le client"');
}, 1000);

// ============================================
// RÉSUMÉ
// ============================================
setTimeout(() => {
  console.log('\n📊 === RÉSUMÉ ===');
  console.log('Si tous les tests sont ✅, l\'extension devrait fonctionner.');
  console.log('Si vous avez des ❌, suivez les solutions 💡 proposées.');
  console.log('\nPour plus d\'aide, consultez: DIAGNOSTIC-ERREURS.md');
}, 2000);
