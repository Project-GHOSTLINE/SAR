#!/usr/bin/env node

/**
 * Script pour nettoyer les analyses de test dans Supabase
 * Usage: node clean-test-analyses.js
 */

const SUPABASE_URL = 'https://dllyzfuqjzuhvshrlmuq.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRsbHl6ZnVxanp1aHZzaHJsbXVxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU5OTU5ODEsImV4cCI6MjA4MTU3MTk4MX0.xskVblRlKdbTST1Mdgz76oR7N2rDq8ZOUgaN-f_TTM4';

async function cleanTestAnalyses() {
  console.log('🧹 Nettoyage des analyses de test...\n');

  try {
    // 1. Récupérer toutes les analyses
    console.log('📊 Récupération de toutes les analyses...');
    const response = await fetch(`${SUPABASE_URL}/rest/v1/client_analyses?select=id,client_name,source,created_at,inverite_guid`, {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      }
    });

    if (!response.ok) {
      throw new Error(`Erreur HTTP: ${response.status}`);
    }

    const analyses = await response.json();
    console.log(`✅ ${analyses.length} analyses trouvées\n`);

    if (analyses.length === 0) {
      console.log('✨ La base de données est déjà vide!');
      return;
    }

    // 2. Afficher la liste
    console.log('📋 Liste des analyses:');
    console.log('─'.repeat(80));
    analyses.forEach((analysis, index) => {
      const date = new Date(analysis.created_at).toLocaleString('fr-CA');
      console.log(`${index + 1}. ${analysis.client_name} (${analysis.source}) - ${date}`);
      console.log(`   ID: ${analysis.id}`);
      console.log(`   GUID: ${analysis.inverite_guid || 'N/A'}`);
      console.log('');
    });
    console.log('─'.repeat(80));

    // 3. Demander confirmation
    console.log('\n⚠️  ATTENTION: Cette action va supprimer TOUTES les analyses!');
    console.log('\n🔴 Pour supprimer TOUTES les analyses, tapez: DELETE ALL');
    console.log('🟢 Pour annuler, tapez: CANCEL\n');

    // Lire l'input utilisateur
    const readline = require('readline');
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    rl.question('Votre choix: ', async (answer) => {
      if (answer.trim() === 'DELETE ALL') {
        console.log('\n🗑️  Suppression en cours...\n');

        // Supprimer toutes les analyses
        for (const analysis of analyses) {
          const deleteResponse = await fetch(`${SUPABASE_URL}/rest/v1/client_analyses?id=eq.${analysis.id}`, {
            method: 'DELETE',
            headers: {
              'apikey': SUPABASE_ANON_KEY,
              'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
            }
          });

          if (deleteResponse.ok) {
            console.log(`✅ Supprimé: ${analysis.client_name} (${analysis.id})`);
          } else {
            console.log(`❌ Erreur: ${analysis.client_name} (${analysis.id})`);
          }
        }

        console.log(`\n✨ ${analyses.length} analyses supprimées avec succès!`);
      } else {
        console.log('\n❌ Annulé - Aucune analyse supprimée');
      }

      rl.close();
    });

  } catch (error) {
    console.error('❌ Erreur:', error.message);
    process.exit(1);
  }
}

// Exécuter
cleanTestAnalyses();
