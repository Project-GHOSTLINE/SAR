# 🐛 MODE DEBUG ACTIVÉ

**Date**: 2026-01-09
**Version**: Mode Debug avec logs détaillés

---

## ✅ CE QUI A CHANGÉ

### Version Debug Activée

Le fichier `content-script.js` a été remplacé par une version **MODE DEBUG** qui:

✅ **Affiche TOUT dans la console**
- Logs détaillés à chaque étape
- Logs colorés pour faciliter la lecture
- Informations de timing (durée des requêtes)
- Headers HTTP complets
- JSON complet affiché

✅ **N'envoie PAS à SAR**
- Pas d'appel à l'API SAR
- Pas de redirection
- Juste affichage des données Inverite

✅ **Interface modifiée**
- Bouton: "Afficher JSON" au lieu de "Analyser le client"
- Affiche un message de succès avec ✅

---

## 📁 FICHIERS

```
content-script-original.js  ← Version originale (sauvegarde)
content-script-debug.js     ← Version debug (source)
content-script.js           ← Version active (copie de debug)
```

---

## 🚀 COMMENT UTILISER

### 1. Recharger l'extension

```
chrome://extensions/
→ IBV Crawler V2
→ 🔄 Recharger
```

### 2. Ouvrir une page Inverite

```
https://www.inverite.com/merchant/request/view/[GUID]
```

### 3. Ouvrir la Console (IMPORTANT!)

```
F12 → Onglet "Console"
```

**Tu DOIS avoir la console ouverte pour voir les logs!**

### 4. Cliquer sur "Afficher JSON"

Le bouton vert en haut à droite de la page.

---

## 📊 CE QUE TU VERRAS

### Étape 1: Configuration
```
⚙️  ÉTAPE 1: CONFIGURATION
   📌 API Inverite URL: https://www.inverite.com/api/v2/fetch
   📌 API Key (10 premiers chars): 09ccfeec2e...
   ✅ Configuration chargée
```

### Étape 2: Détection du GUID
```
🔍 ÉTAPE 2: DÉTECTION DU GUID
   📌 URL actuelle: https://www.inverite.com/merchant/request/view/238DAD06...
   📌 Pathname: /merchant/request/view/238DAD06...
   📌 Regex match résultat: [Array]
   ✅ GUID DÉTECTÉ!
   📌 GUID complet: 238DAD06-C8C6-4BE9-8954-E23E936DD5D9
   📌 Longueur: 36 caractères
```

### Étape 3: Initialisation
```
🎨 ÉTAPE 3: INITIALISATION DE L'INTERFACE
   📌 Création du bouton...
   📌 Ajout du bouton au DOM...
   ✅ Bouton injecté dans la page
   📌 ID du bouton: ibv-analyze-btn
   📌 Position: DOMRect {x: ..., y: ...}
   📌 Attachement du gestionnaire de clic...
   ✅ Handler attaché au bouton
```

### Étape 4: Récupération des données
```
📡 ÉTAPE 4: RÉCUPÉRATION DES DONNÉES INVERITE
   📌 Construction de l'URL...
   📌 URL complète: https://www.inverite.com/api/v2/fetch/238DAD06-C8C6-4BE9-8954-E23E936DD5D9

   📌 Préparation de la requête fetch...
   📌 Méthode: GET
   📌 Headers:
      - Auth: 09ccfeec2e0c6de...
      - Content-Type: application/json

   ⏳ Envoi de la requête...
   ✅ Réponse reçue!
   📌 Temps de réponse: 468 ms
   📌 Status HTTP: 200 OK
   📌 Headers de réponse:
      - content-type: application/json
      - content-length: 426178
      ...

   ⏳ Parsing du JSON...
   ✅ JSON PARSÉ AVEC SUCCÈS!
```

### Étape 5: Affichage des données
```
📊 ÉTAPE 5: AFFICHAGE DES DONNÉES COMPLÈTES

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 INFORMATIONS CLIENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👤 Nom: KAYLA FORTIN-BECHAMP
📅 Date complète: 2026-01-09 17:16:10
🆔 Référence: KF53988
🔑 Request ID: 238DAD06-C8C6-4BE9-8954-E23E936DD5D9
✅ Status: Verified
📝 Type: bankverify

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 COMPTES BANCAIRES (1)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🏦 COMPTE 1
   📌 Type: chequing
   📌 Institution: 010
   📌 Compte: 7552831
   📌 Transit: 00591
   💵 Balance disponible: 0.00 $
   💵 Balance actuelle: 175.94 $
   📊 Transactions: 245
   📊 Première transaction: {date: "2024-10-10", description: "...", montant: "..."}

📈 RÉSUMÉ TOTAL
   📌 Nombre de comptes: 1
   📌 Balance totale: 175.94 $
   📌 Nombre de transactions: 245

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📦 JSON COMPLET (clique pour développer)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{name: "KAYLA FORTIN-BECHAMP", complete_datetime: "2026-01-09 17:16:10", ...}
   ▼ accounts: Array(1)
      ▼ 0: {type: "chequing", available_balance: "0.00", ...}
         ▼ transactions: Array(245)
            0: {date: "2024-10-10", description: "...", amount: "..."}
            1: {date: "2024-10-09", description: "...", amount: "..."}
            ...

📝 JSON FORMATÉ (copie-colle):
{
  "name": "KAYLA FORTIN-BECHAMP",
  "complete_datetime": "2026-01-09 17:16:10",
  ...
}

📊 STATISTIQUES
   📌 Taille JSON: 426178 caractères
   📌 Taille JSON: 416.19 KB
   📌 Nombre de clés: 8

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ SUCCÈS - TOUTES LES DONNÉES AFFICHÉES CI-DESSUS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 🎨 COULEURS DES LOGS

- 🟢 **Vert** = Succès, titres principaux
- 🟠 **Orange** = Étapes, en-têtes de sections
- 🔵 **Bleu** = Informations client, JSON
- 🟣 **Violet** = JSON complet
- 🔴 **Rouge** = Erreurs

---

## 🔄 REVENIR À LA VERSION NORMALE

Si tu veux revenir à la version qui envoie à SAR:

```bash
cd /Users/xunit/Desktop/IBV-Crawler-V2-CLEAN
cp content-script-original.js content-script.js
```

Puis recharger l'extension dans Chrome.

---

## ❌ EN CAS DE PROBLÈME

### Aucun log dans la console?

1. **Console pas ouverte** → F12 → Onglet "Console"
2. **Extension pas rechargée** → chrome://extensions/ → 🔄
3. **Page pas fermée/rouverte** → FERMER l'onglet et ROUVRIR

### Erreur 404?

1. **GUID invalide** → Utiliser un autre dossier client
2. **Ancienne clé API** → Vérifier que la nouvelle clé est bien dans content-script.js

### Erreur réseau?

1. **API Inverite down** → Attendre et réessayer
2. **Connexion internet** → Vérifier la connexion

---

## 📋 CHECKLIST DE TEST

- [ ] Extension rechargée
- [ ] Page Inverite ouverte (avec GUID dans l'URL)
- [ ] Console ouverte (F12)
- [ ] Bouton "Afficher JSON" visible
- [ ] Click sur le bouton
- [ ] Logs détaillés apparaissent
- [ ] JSON complet affiché
- [ ] Aucune erreur rouge

---

**Mode Debug activé par**: Claude
**Date**: 2026-01-09
**Objectif**: Voir TOUTES les étapes et le JSON complet
