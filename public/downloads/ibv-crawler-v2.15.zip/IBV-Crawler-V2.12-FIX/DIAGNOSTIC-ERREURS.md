# 🔍 DIAGNOSTIC DES ERREURS - IBV CRAWLER V2

## 📋 ÉTAPE 1 : Identifier l'erreur exacte

1. **Ouvrir la page Inverite**
   - Exemple : `https://www.inverite.com/merchant/request/view/[GUID]`

2. **Ouvrir la Console Chrome**
   - Appuyez sur `F12`
   - Onglet "Console"

3. **Cliquer sur "Analyser le client"**

4. **Regarder les messages dans la console**

---

## ❌ ERREUR 404 - "Inverite API: 404"

### Cause probable :
- Le GUID dans l'URL n'existe pas ou est invalide
- L'URL de l'API Inverite est incorrecte

### Solution :

1. **Vérifier le GUID dans la console**
   - Cherchez : `✅ GUID détecté: ...`
   - Le GUID doit ressembler à : `238DAD06-C8C6-4BE9-8954-E23E936DD5D9`

2. **Tester manuellement l'API Inverite**
   ```bash
   # Remplacez [GUID] par votre GUID réel
   curl -X GET "https://www.inverite.com/api/v2/fetch/[GUID]" \
     -H "Auth: 09ccfeec2e0c6de5eca68f2165cb81d2947" \
     -v
   ```

3. **Si vous obtenez 404**
   - Le GUID n'existe pas dans Inverite
   - Essayez avec un autre dossier client

4. **Si vous obtenez 200**
   - L'API fonctionne, le problème est ailleurs

---

## 🔑 ERREUR TOKEN - "Token SAR manquant" ou "Token invalide"

### Cause probable :
- Le token n'est pas configuré
- Le token a expiré
- Le token est incorrect

### Solution :

#### A. Vérifier si le token est configuré

1. **Dans la console, cherchez :**
   ```
   🔑 Token SAR: ✅ Configuré
   ```
   ou
   ```
   🔑 Token SAR: ❌ Manquant
   ```

2. **Si "❌ Manquant"** → Configurez le token (voir étape B)

#### B. Configurer/Régénérer le token

1. **Aller sur le dashboard SAR**
   - URL : `https://admin.solutionargentrapide.ca/admin/extension-token`
   - Login : `admin@solutionargentrapide.ca`
   - Password : `FredRosa%1978`

2. **Copier le nouveau token JWT**

3. **Configurer l'extension**
   - Cliquer sur l'icône de l'extension (puzzle 🧩)
   - Coller le token
   - Cliquer "💾 Sauvegarder"
   - Cliquer "🧪 Tester" → Doit dire "✅ Token valide!"

4. **Recharger la page Inverite**
   - `Ctrl + R` ou `Cmd + R`

5. **Réessayer "Analyser le client"**

---

## 🌐 ERREUR RÉSEAU - "Failed to fetch" ou "Network error"

### Cause probable :
- Problème de connexion internet
- L'API SAR est hors ligne
- CORS bloqué

### Solution :

1. **Tester l'API SAR manuellement**
   ```bash
   # Test basique (devrait retourner 401 si l'API fonctionne)
   curl -X POST "https://admin.solutionargentrapide.ca/api/admin/client-analysis" \
     -H "Content-Type: application/json" \
     -d '{"test":"data"}' \
     -v
   ```

2. **Si vous obtenez 401** → L'API fonctionne, c'est le token
3. **Si timeout** → L'API est hors ligne ou problème réseau

---

## 🔧 ERREUR 401 - "Unauthorized" ou "Token Bearer invalide"

### Cause probable :
- Le token a expiré
- Le token est incorrect
- Vous êtes déconnecté du dashboard SAR

### Solution :

1. **Vérifier si vous êtes connecté au dashboard**
   - Ouvrir : `https://admin.solutionargentrapide.ca`
   - Si page de login → Vous êtes déconnecté

2. **Se reconnecter au dashboard**
   - Email : `admin@solutionargentrapide.ca`
   - Password : `FredRosa%1978`

3. **Régénérer un nouveau token**
   - Aller sur : `/admin/extension-token`
   - Copier le nouveau token

4. **Reconfigurer l'extension** (voir section B ci-dessus)

---

## 🧪 TEST COMPLET DE L'EXTENSION

Si vous voulez tester chaque composant :

### 1. Test Token SAR

Dans la console de l'extension :
```javascript
chrome.storage.sync.get(['sarToken'], (result) => {
  console.log('Token:', result.sarToken);
});
```

### 2. Test API Inverite

```javascript
// Remplacez par un GUID valide
const guid = "238DAD06-C8C6-4BE9-8954-E23E936DD5D9";
fetch(`https://www.inverite.com/api/v2/fetch/${guid}`, {
  method: 'GET',
  headers: {
    'Auth': '09ccfeec2e0c6de5eca68f2165cb81d2947'
  }
})
.then(r => r.json())
.then(data => console.log('✅ Inverite:', data))
.catch(err => console.error('❌ Inverite:', err));
```

### 3. Test API SAR

```javascript
// Remplacez TOKEN par votre token réel
const token = "eyJ...";
fetch('https://admin.solutionargentrapide.ca/api/admin/client-analysis', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify({
    client_name: "Test",
    source: "test",
    raw_data: {}
  })
})
.then(r => r.json())
.then(data => console.log('✅ SAR:', data))
.catch(err => console.error('❌ SAR:', err));
```

---

## 📸 CAPTURE D'ÉCRAN DE LA CONSOLE

Pour m'aider à diagnostiquer, envoyez-moi une capture d'écran de la console Chrome montrant :
- Les messages au chargement de la page
- Les messages après avoir cliqué sur "Analyser le client"
- L'erreur exacte affichée

---

## 🚨 ERREURS COMMUNES ET SOLUTIONS RAPIDES

| Erreur | Solution rapide |
|--------|----------------|
| `❌ Pas de GUID dans URL` | Vérifiez que l'URL contient `/view/[GUID]` |
| `Token SAR manquant` | Configurez le token dans le popup |
| `Inverite API: 404` | Le GUID n'existe pas, utilisez un autre dossier |
| `API Error: 401` | Token expiré, régénérez un nouveau token |
| `Failed to fetch` | Problème réseau ou API hors ligne |
| `Token Bearer invalide` | Reconnectez-vous au dashboard SAR |

---

## 📞 BESOIN D'AIDE ?

Si aucune solution ne fonctionne, donnez-moi :
1. Le message d'erreur EXACT de la console
2. Le GUID que vous essayez d'utiliser
3. Si le token est configuré (✅ ou ❌)
4. Le code de statut HTTP (404, 401, 500, etc.)
