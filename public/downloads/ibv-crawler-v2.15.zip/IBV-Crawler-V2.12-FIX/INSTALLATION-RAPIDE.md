# ⚡ INSTALLATION RAPIDE (2 minutes)

## ✅ EXTENSION VÉRIFIÉE ET PRÊTE

**Toutes les vérifications**: ✅ PASSÉES
- ✅ 6 fichiers présents
- ✅ Syntaxe JavaScript valide
- ✅ manifest.json valide
- ✅ API Inverite: 200 OK
- ✅ API SAR: 401 (normal sans token)

---

## 📋 INSTALLATION (30 secondes)

### 1. Charger l'extension

```
chrome://extensions/
↓
Mode développeur: ON (en haut à droite)
↓
"Charger l'extension non empaquetée"
↓
Sélectionner: /Users/xunit/Desktop/IBV-Crawler-V2-CLEAN
↓
✅ "IBV Crawler V2" version 2.0.0 apparaît
```

---

## 🔑 CONFIGURATION (1 minute)

### 2. Obtenir le token

```
1. Aller sur: https://admin.solutionargentrapide.ca/admin/extension-token
2. Se connecter: admin@solutionargentrapide.ca / FredRosa%1978
3. Copier le token JWT (bouton "Copier")
```

### 3. Configurer l'extension

```
1. Cliquer sur l'icône de l'extension (puzzle 🧩)
2. Coller le token dans le champ
3. Cliquer "💾 Sauvegarder"
4. Cliquer "🧪 Tester" → Doit dire "✅ Token valide!"
```

---

## 🚀 UTILISATION (30 secondes)

### 4. Tester

```
1. Ouvrir: https://www.inverite.com/merchant/request/view/238DAD06-C8C6-4BE9-8954-E23E936DD5D9

2. F12 → Console (pour voir les logs)

3. Tu DOIS voir:
   🚀 IBV Crawler V2 - Démarrage
   🔑 Token SAR: ✅ Configuré
   ✅ GUID détecté: 238DAD06...
   ✅ Bouton injecté
   ✅ Handler attaché
   ✅ IBV Crawler V2 - Prêt

4. Un bouton vert "Analyser le client" apparaît en haut à droite

5. Cliquer sur le bouton

6. Vérifier la console:
   📡 Récupération données Inverite...
   ✅ Données Inverite reçues: KAYLA FORTIN-BECHAMP
   📊 Client: KAYLA FORTIN-BECHAMP
      Comptes: 1
      Balance: 175.94 $
      Transactions: X
   📤 Envoi à SAR API...
   ✅ Données envoyées! ID: [UUID]
   🚀 Redirection vers /analyse?id=[UUID]

7. Après 1 seconde → Redirection automatique

8. Page d'analyse affiche toutes les données ✅
```

---

## ❌ SI PROBLÈME

### Aucun log dans console?

```
1. chrome://extensions/ → IBV Crawler V2 → 🔄 Recharger
2. FERMER l'onglet Inverite
3. ROUVRIR l'onglet Inverite
4. F12 → Console
5. Tu DOIS voir: "🚀 IBV Crawler V2 - Démarrage"
```

### Token manquant?

```
1. Cliquer sur l'icône de l'extension
2. Refaire la configuration (étape 2-3)
```

### Token invalide?

```
1. Se déconnecter du dashboard SAR
2. Se reconnecter
3. Régénérer le token
4. Reconfigurer l'extension
```

---

## 📊 VÉRIFICATION COMPLÈTE

Tu peux exécuter le script de vérification:

```bash
cd /Users/xunit/Desktop/IBV-Crawler-V2-CLEAN
./verify.sh
```

**Résultat attendu**: Toutes les vérifications ✅ (déjà fait, tout passe!)

---

**C'est tout!** L'extension est prête à l'emploi. 🎉

**Lis `README.md` pour plus de détails.**
