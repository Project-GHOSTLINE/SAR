# ⚡ DÉMARRAGE RAPIDE - MODE DEBUG

**Version actuelle**: MODE DEBUG avec logs détaillés
**Objectif**: Voir TOUT dans la console + Afficher le JSON complet

---

## 🚀 3 ÉTAPES (2 minutes)

### 1️⃣ Recharger l'extension

```
chrome://extensions/
↓
Trouver "IBV Crawler V2"
↓
Cliquer sur 🔄 Recharger
```

**IMPORTANT**: Après le reload, **FERME** tous les onglets Inverite ouverts!

---

### 2️⃣ Ouvrir une page Inverite + Console

```
1. Ouvrir: https://www.inverite.com/merchant/request/view/[GUID]

   Exemple:
   https://www.inverite.com/merchant/request/view/238DAD06-C8C6-4BE9-8954-E23E936DD5D9

2. Appuyer sur F12 (ouvrir la Console)

3. Onglet "Console" (pas Elements, pas Network)
```

**Tu DOIS voir ces logs dès le chargement**:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 IBV CRAWLER V2 - MODE DEBUG ACTIVÉ
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 Ce mode affiche TOUT dans la console
📋 Ne fait PAS d'envoi à SAR API

⚙️  ÉTAPE 1: CONFIGURATION
   📌 API Inverite URL: ...
   ✅ Configuration chargée

🔍 ÉTAPE 2: DÉTECTION DU GUID
   ✅ GUID DÉTECTÉ!
   📌 GUID complet: 238DAD06-C8C6-4BE9-8954-E23E936DD5D9

🎨 ÉTAPE 3: INITIALISATION DE L'INTERFACE
   ✅ Bouton injecté dans la page

✅ IBV CRAWLER V2 - MODE DEBUG PRÊT
```

---

### 3️⃣ Cliquer sur "Afficher JSON"

```
1. Tu vois un bouton vert "Afficher JSON" en haut à droite
2. Clique dessus
3. Regarde la console → PLEIN de logs détaillés!
```

**Tu verras**:
- 📡 Récupération des données Inverite (avec timing, headers, status)
- 📊 Informations client (nom, date, référence)
- 💰 Comptes bancaires détaillés
- 📦 JSON COMPLET (cliquable pour développer)
- 📝 JSON formaté (copie-colle)
- 📊 Statistiques (taille, nombre de clés)

---

## ✅ CE QUE TU DOIS VOIR

### Avant le click
```
✅ IBV CRAWLER V2 - MODE DEBUG PRÊT
📋 Cliquez sur le bouton "Afficher JSON" pour voir les données
```

### Après le click
```
🎯 CLICK SUR LE BOUTON "AFFICHER JSON"
   📌 Timestamp: 2026-01-09T...
   📌 GUID à récupérer: 238DAD06-C8C6-4BE9-8954-E23E936DD5D9

📡 ÉTAPE 4: RÉCUPÉRATION DES DONNÉES INVERITE
   📌 URL complète: https://www.inverite.com/api/v2/fetch/238DAD06-C8C6-4BE9-8954-E23E936DD5D9
   📌 Méthode: GET
   📌 Headers: ...

   ⏳ Envoi de la requête...
   ✅ Réponse reçue!
   📌 Temps de réponse: 468 ms
   📌 Status HTTP: 200 OK
   ✅ JSON PARSÉ AVEC SUCCÈS!

📊 ÉTAPE 5: AFFICHAGE DES DONNÉES COMPLÈTES

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 INFORMATIONS CLIENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👤 Nom: KAYLA FORTIN-BECHAMP
📅 Date complète: 2026-01-09 17:16:10
🆔 Référence: KF53988
...

💰 COMPTES BANCAIRES (1)

🏦 COMPTE 1
   📌 Type: chequing
   💵 Balance actuelle: 175.94 $
   📊 Transactions: 245

📈 RÉSUMÉ TOTAL
   📌 Nombre de comptes: 1
   📌 Balance totale: 175.94 $
   📌 Nombre de transactions: 245

📦 JSON COMPLET (clique pour développer)
{name: "KAYLA FORTIN-BECHAMP", ...}  ← CLIQUE ICI!

📝 JSON FORMATÉ (copie-colle):
{
  "name": "KAYLA FORTIN-BECHAMP",
  "complete_datetime": "2026-01-09 17:16:10",
  ...
}

✅ SUCCÈS - TOUTES LES DONNÉES AFFICHÉES CI-DESSUS
```

---

## ❌ PROBLÈMES COURANTS

### 1. Aucun log dans la console?

**Solution**:
```
1. Extension rechargée? → chrome://extensions/ → 🔄
2. Console ouverte? → F12 → Onglet "Console"
3. Page fermée/rouverte? → FERMER l'onglet, ROUVRIR
```

---

### 2. Je vois les logs de démarrage mais pas de bouton?

**Solution**:
```
1. Scroll en haut de la page
2. Le bouton est position: fixed en haut à droite
3. Si toujours pas visible → Inspecter l'élément #ibv-analyze-btn
```

---

### 3. Erreur "Inverite API: 404"?

**Solution**:
```
1. Le GUID n'existe pas
2. Essayer avec un autre dossier client Inverite
3. Vérifier l'URL contient /view/[GUID]
```

---

### 4. Erreur réseau?

**Solution**:
```
1. Vérifier connexion internet
2. Tester manuellement:
   cd /Users/xunit/Desktop/IBV-Crawler-V2-CLEAN
   ./verify.sh
```

---

## 🔄 REVENIR À LA VERSION NORMALE

Si tu veux envoyer à SAR au lieu de juste afficher:

```bash
cd /Users/xunit/Desktop/IBV-Crawler-V2-CLEAN
cp content-script-original.js content-script.js
```

Puis:
```
chrome://extensions/ → IBV Crawler V2 → 🔄 Recharger
```

---

## 📁 VERSIONS DISPONIBLES

```
content-script.js          ← VERSION ACTIVE (actuellement: DEBUG)
content-script-debug.js    ← Source du mode debug
content-script-original.js ← Version normale (avec envoi SAR)
```

---

## 📋 CHECKLIST FINALE

- [ ] ✅ Extension rechargée
- [ ] ✅ Page Inverite avec GUID ouverte
- [ ] ✅ Console Chrome ouverte (F12)
- [ ] ✅ Logs de démarrage visibles
- [ ] ✅ Bouton "Afficher JSON" visible
- [ ] ✅ Click sur le bouton
- [ ] ✅ Plein de logs détaillés
- [ ] ✅ JSON complet affiché

---

**Si tout est ✅ → Parfait! Tu vois toutes les données! 🎉**

**Si tu as un problème → Lis MODE-DEBUG.md pour plus de détails**

---

**Mode Debug créé par**: Claude
**Date**: 2026-01-09
**Objectif**: Voir CHAQUE étape et le JSON complet
