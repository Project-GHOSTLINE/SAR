// ============================================
// IBV CRAWLER V2.03 - FLINKS + INVERITE
// ============================================

console.log('🚀 IBV Crawler V2.03 - Démarrage');

// ============================================
// CONFIGURATION
// ============================================
const CONFIG = {
  INVERITE_API_KEY: '09ccfeec2e0c6de5eca68f2165cb81d2947',
  INVERITE_API_URL: 'https://www.inverite.com/api/v2/fetch',

  // Supabase - Direct connection
  SUPABASE_URL: 'https://dllyzfuqjzuhvshrlmuq.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRsbHl6ZnVxanp1aHZzaHJsbXVxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU5OTU5ODEsImV4cCI6MjA4MTU3MTk4MX0.xskVblRlKdbTST1Mdgz76oR7N2rDq8ZOUgaN-f_TTM4'
};

// ============================================
// 1. DÉTECTER LE TYPE DE SITE
// ============================================
function detectSiteType() {
  const hostname = window.location.hostname;
  const pathname = window.location.pathname;

  // Vérifier Inverite
  if (hostname.includes('inverite.com')) {
    const inveriteGuid = pathname.match(/\/view\/([A-Fa-f0-9-]+)/);
    if (inveriteGuid) {
      return {
        type: 'inverite',
        guid: inveriteGuid[1]
      };
    }
  }

  // Vérifier Flinks
  if (hostname.includes('flinks') || hostname.includes('fin.ag')) {
    // TODO: Détecter l'identifiant Flinks (à définir avec l'utilisateur)
    return {
      type: 'flinks',
      guid: null // On va définir comment extraire ça ensemble
    };
  }

  return null;
}

const siteInfo = detectSiteType();

if (!siteInfo) {
  console.log('❌ Site non supporté - Extension inactive');
} else {
  console.log(`✅ Site détecté: ${siteInfo.type.toUpperCase()}`);
  if (siteInfo.guid) {
    console.log(`   GUID: ${siteInfo.guid.substring(0, 12)}...`);
  }
  initExtension(siteInfo);
}

// ============================================
// 2. INITIALISER L'EXTENSION
// ============================================
function initExtension(siteInfo) {
  // Créer le bouton
  const button = document.createElement('button');
  button.id = 'ibv-analyze-btn';
  button.className = 'ibv-analyze-button';

  // Texte adapté au site
  const buttonText = siteInfo.type === 'inverite'
    ? 'Analyser le client (Inverite)'
    : 'Analyser le client (Flinks)';

  button.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
      <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
      <line x1="12" y1="22.08" x2="12" y2="12"></line>
    </svg>
    <span>${buttonText}</span>
  `;

  // Ajouter au DOM
  document.body.appendChild(button);
  console.log('✅ Bouton injecté');

  // Attacher le handler avec le type de site
  button.addEventListener('click', (event) => handleAnalyzeClick(event, siteInfo));
  console.log('✅ Handler attaché');
}

// ============================================
// 3. ROUTER SELON LE TYPE
// ============================================
async function handleAnalyzeClick(event, siteInfo) {
  const button = event.currentTarget;
  console.log(`🎯 Click sur le bouton - Type: ${siteInfo.type}`);

  if (siteInfo.type === 'inverite') {
    await handleInveriteAnalysis(button, siteInfo.guid);
  } else if (siteInfo.type === 'flinks') {
    await handleFlinksAnalysis(button, siteInfo);
  }
}

// ============================================
// 4. INVERITE - LOGIQUE EXISTANTE
// ============================================
async function handleInveriteAnalysis(button, guid) {
  const originalContent = button.innerHTML;

  // Désactiver le bouton
  button.disabled = true;
  button.innerHTML = `
    <div class="spinner"></div>
    <span>Analyse en cours...</span>
  `;

  try {
    // Étape 1: Récupérer données Inverite
    const inveriteData = await fetchInveriteData(guid);

    // Étape 2: Extraire les infos
    const clientData = extractInveriteClientInfo(inveriteData, guid);
    console.log('📊 Client:', clientData.client_name);
    console.log('   Comptes:', clientData.total_accounts);
    console.log('   Balance:', clientData.total_balance.toFixed(2), '$');
    console.log('   Transactions:', clientData.total_transactions);

    // Étape 3: Envoyer à Supabase
    const result = await sendToSupabase(clientData);

    // Étape 4: Rediriger
    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
        <polyline points="22 4 12 14.01 9 11.01"></polyline>
      </svg>
      <span>Succès! Redirection...</span>
    `;

    console.log('🚀 Redirection vers /analyse?id=' + result.id);

    setTimeout(() => {
      window.location.href = `http://localhost:3000/analyse?id=${result.id}`;
    }, 1000);

  } catch (error) {
    console.error('❌ ERREUR:', error);

    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>
      <span>Erreur: ${error.message}</span>
    `;

    setTimeout(() => {
      button.disabled = false;
      button.innerHTML = originalContent;
    }, 3000);
  }
}

async function fetchInveriteData(guid) {
  console.log('📡 Récupération données Inverite...');

  try {
    const apiUrl = `${CONFIG.INVERITE_API_URL}/${guid}`;
    console.log('   URL:', apiUrl);

    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Auth': CONFIG.INVERITE_API_KEY,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Inverite API: ${response.status}`);
    }

    const data = await response.json();
    console.log('✅ Données Inverite reçues:', data.name || 'Client');
    return data;

  } catch (error) {
    console.error('❌ Erreur Inverite API:', error);
    throw error;
  }
}

function extractInveriteClientInfo(data, guid) {
  const clientName = data.name || 'Client Inconnu';

  let totalAccounts = 0;
  let totalBalance = 0;
  let totalTransactions = 0;

  if (data.accounts && Array.isArray(data.accounts)) {
    totalAccounts = data.accounts.length;

    data.accounts.forEach(account => {
      if (account.current_balance) {
        totalBalance += parseFloat(account.current_balance) || 0;
      }
      if (account.transactions && Array.isArray(account.transactions)) {
        totalTransactions += account.transactions.length;
      }
    });
  }

  return {
    client_name: clientName,
    source: 'inverite',
    inverite_guid: guid,
    raw_data: data,
    total_accounts: totalAccounts,
    total_balance: totalBalance,
    total_transactions: totalTransactions
  };
}

// ============================================
// 5. FLINKS - À DÉVELOPPER ENSEMBLE
// ============================================
async function handleFlinksAnalysis(button, siteInfo) {
  const originalContent = button.innerHTML;

  button.disabled = true;
  button.innerHTML = `
    <div class="spinner"></div>
    <span>Analyse Flinks en cours...</span>
  `;

  try {
    console.log('🔵 FLINKS - Analyse démarrée');
    console.log('   URL actuelle:', window.location.href);

    // TODO: Étape par étape avec l'utilisateur
    // 1. Comment récupérer les données Flinks?
    // 2. Où se trouve l'identifiant unique?
    // 3. Comment extraire le JSON?

    throw new Error('Logique Flinks à implémenter - Prêt pour les instructions!');

  } catch (error) {
    console.error('❌ ERREUR FLINKS:', error);

    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>
      <span>${error.message}</span>
    `;

    setTimeout(() => {
      button.disabled = false;
      button.innerHTML = originalContent;
    }, 5000);
  }
}

// ============================================
// 6. SUPABASE - COMMUN AUX DEUX
// ============================================
async function sendToSupabase(clientData) {
  console.log('📤 Envoi à Supabase...');

  try {
    // Vérifier si ce GUID existe déjà
    console.log('   Vérification si GUID existe...');
    const guidField = clientData.source === 'inverite' ? 'inverite_guid' : 'flinks_guid';
    const guidValue = clientData.inverite_guid || clientData.flinks_guid;

    const checkResponse = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/client_analyses?${guidField}=eq.${guidValue}&select=id`, {
      method: 'GET',
      headers: {
        'apikey': CONFIG.SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}`
      }
    });

    const existing = await checkResponse.json();
    const existingId = existing.length > 0 ? existing[0].id : null;

    // Préparer les données
    const id = existingId || crypto.randomUUID();
    const dataToSave = {
      id: id,
      client_name: clientData.client_name,
      source: clientData.source,
      inverite_guid: clientData.inverite_guid || null,
      flinks_guid: clientData.flinks_guid || null,
      raw_data: clientData.raw_data,
      total_accounts: clientData.total_accounts,
      total_balance: clientData.total_balance,
      total_transactions: clientData.total_transactions,
      created_at: existingId ? undefined : new Date().toISOString()
    };

    if (existingId) {
      delete dataToSave.created_at;
    }

    console.log(`   ${existingId ? 'Mise à jour' : 'Création'} des données:`, {
      id,
      client_name: dataToSave.client_name,
      accounts: dataToSave.total_accounts,
      balance: dataToSave.total_balance
    });

    // Upsert
    const response = await fetch(`${CONFIG.SUPABASE_URL}/rest/v1/client_analyses`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': CONFIG.SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${CONFIG.SUPABASE_ANON_KEY}`,
        'Prefer': 'resolution=merge-duplicates,return=representation'
      },
      body: JSON.stringify(dataToSave)
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('   Erreur Supabase:', errorData);
      throw new Error(`Supabase Error: ${response.status} - ${errorData}`);
    }

    const result = await response.json();
    console.log(`✅ Données ${existingId ? 'mises à jour' : 'enregistrées'} dans Supabase! ID:`, id);

    return { id, ...result[0] };

  } catch (error) {
    console.error('❌ Erreur Supabase:', error);
    throw error;
  }
}

console.log('✅ IBV Crawler V2.03 - Prêt (Flinks + Inverite)');
