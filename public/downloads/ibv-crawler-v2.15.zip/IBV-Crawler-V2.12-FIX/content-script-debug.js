// ============================================
// IBV CRAWLER V2 - VERSION DEBUG (LOGS DÉTAILLÉS)
// ============================================
// Cette version affiche TOUT dans la console
// Ne fait PAS d'envoi à SAR - juste affichage JSON

console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #00ff00; font-weight: bold');
console.log('%c🚀 IBV CRAWLER V2 - MODE DEBUG ACTIVÉ', 'font-size: 20px; color: #00ff00; font-weight: bold');
console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #00ff00; font-weight: bold');
console.log('📋 Ce mode affiche TOUT dans la console');
console.log('📋 Ne fait PAS d\'envoi à SAR API');
console.log('');

// ============================================
// CONFIGURATION
// ============================================
console.log('%c⚙️  ÉTAPE 1: CONFIGURATION', 'color: #ffaa00; font-weight: bold; font-size: 14px');
const CONFIG = {
  INVERITE_API_KEY: '09ccfeec2e0c6de5eca68f2165cb81d2947',
  INVERITE_API_URL: 'https://www.inverite.com/api/v2/fetch',
  SAR_API_URL: 'https://admin.solutionargentrapide.ca/api/admin/client-analysis'
};
console.log('   📌 API Inverite URL:', CONFIG.INVERITE_API_URL);
console.log('   📌 API Key (10 premiers chars):', CONFIG.INVERITE_API_KEY.substring(0, 10) + '...');
console.log('   ✅ Configuration chargée');
console.log('');

// ============================================
// 2. DÉTECTER LE GUID DANS L'URL
// ============================================
console.log('%c🔍 ÉTAPE 2: DÉTECTION DU GUID', 'color: #ffaa00; font-weight: bold; font-size: 14px');
console.log('   📌 URL actuelle:', window.location.href);
console.log('   📌 Pathname:', window.location.pathname);

function getGuidFromUrl() {
  const match = window.location.pathname.match(/\/view\/([A-Fa-f0-9-]+)/);
  console.log('   📌 Regex match résultat:', match);
  return match ? match[1] : null;
}

const guid = getGuidFromUrl();

if (!guid) {
  console.log('%c   ❌ PAS DE GUID TROUVÉ - Extension inactive', 'color: red; font-weight: bold');
  console.log('   💡 Assurez-vous d\'être sur une URL comme:');
  console.log('      https://www.inverite.com/merchant/request/view/[GUID]');
} else {
  console.log('%c   ✅ GUID DÉTECTÉ!', 'color: #00ff00; font-weight: bold');
  console.log('   📌 GUID complet:', guid);
  console.log('   📌 Longueur:', guid.length, 'caractères');
  console.log('');
  initExtension();
}

// ============================================
// 3. INITIALISER L'EXTENSION
// ============================================
function initExtension() {
  console.log('%c🎨 ÉTAPE 3: INITIALISATION DE L\'INTERFACE', 'color: #ffaa00; font-weight: bold; font-size: 14px');

  // Créer le bouton
  console.log('   📌 Création du bouton...');
  const button = document.createElement('button');
  button.id = 'ibv-analyze-btn';
  button.className = 'ibv-analyze-button';
  button.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
      <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
      <line x1="12" y1="22.08" x2="12" y2="12"></line>
    </svg>
    <span>Afficher JSON</span>
  `;

  // Ajouter au DOM
  console.log('   📌 Ajout du bouton au DOM...');
  document.body.appendChild(button);
  console.log('   ✅ Bouton injecté dans la page');
  console.log('   📌 ID du bouton:', button.id);
  console.log('   📌 Position:', button.getBoundingClientRect());

  // Attacher le handler
  console.log('   📌 Attachement du gestionnaire de clic...');
  button.addEventListener('click', handleAnalyzeClick);
  console.log('   ✅ Handler attaché au bouton');
  console.log('');
}

// ============================================
// 4. RÉCUPÉRER DONNÉES INVERITE
// ============================================
async function fetchInveriteData(guid) {
  console.log('%c📡 ÉTAPE 4: RÉCUPÉRATION DES DONNÉES INVERITE', 'color: #ffaa00; font-weight: bold; font-size: 14px');

  const apiUrl = `${CONFIG.INVERITE_API_URL}/${guid}`;
  console.log('   📌 Construction de l\'URL...');
  console.log('   📌 URL complète:', apiUrl);
  console.log('');

  console.log('   📌 Préparation de la requête fetch...');
  console.log('   📌 Méthode: GET');
  console.log('   📌 Headers:');
  console.log('      - Auth:', CONFIG.INVERITE_API_KEY.substring(0, 15) + '...');
  console.log('      - Content-Type: application/json');
  console.log('');

  console.log('   ⏳ Envoi de la requête...');
  const startTime = Date.now();

  try {
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Auth': CONFIG.INVERITE_API_KEY,
        'Content-Type': 'application/json'
      }
    });

    const endTime = Date.now();
    const duration = endTime - startTime;

    console.log('   ✅ Réponse reçue!');
    console.log('   📌 Temps de réponse:', duration, 'ms');
    console.log('   📌 Status HTTP:', response.status, response.statusText);
    console.log('   📌 Headers de réponse:');
    response.headers.forEach((value, key) => {
      console.log(`      - ${key}: ${value}`);
    });
    console.log('');

    if (!response.ok) {
      console.log('%c   ❌ ERREUR HTTP!', 'color: red; font-weight: bold');
      console.log('   📌 Status:', response.status);
      console.log('   📌 Status Text:', response.statusText);
      throw new Error(`Inverite API: ${response.status}`);
    }

    console.log('   ⏳ Parsing du JSON...');
    const data = await response.json();

    console.log('%c   ✅ JSON PARSÉ AVEC SUCCÈS!', 'color: #00ff00; font-weight: bold');
    console.log('');

    return data;

  } catch (error) {
    console.log('%c   ❌ ERREUR LORS DE LA RÉCUPÉRATION!', 'color: red; font-weight: bold');
    console.error('   📌 Type d\'erreur:', error.name);
    console.error('   📌 Message:', error.message);
    console.error('   📌 Stack:', error.stack);
    throw error;
  }
}

// ============================================
// 5. AFFICHER LES DONNÉES COMPLÈTES
// ============================================
function displayFullData(data) {
  console.log('%c📊 ÉTAPE 5: AFFICHAGE DES DONNÉES COMPLÈTES', 'color: #ffaa00; font-weight: bold; font-size: 14px');
  console.log('');

  // Afficher les informations principales
  console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #00aaff; font-weight: bold');
  console.log('%c📋 INFORMATIONS CLIENT', 'color: #00aaff; font-weight: bold; font-size: 16px');
  console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #00aaff; font-weight: bold');
  console.log('');

  console.log('👤 Nom:', data.name || 'N/A');
  console.log('📅 Date complète:', data.complete_datetime || 'N/A');
  console.log('🆔 Référence:', data.referenceid || 'N/A');
  console.log('🔑 Request ID:', data.request || 'N/A');
  console.log('✅ Status:', data.status || 'N/A');
  console.log('📝 Type:', data.type || 'N/A');
  console.log('');

  // Compter et afficher les comptes
  if (data.accounts && Array.isArray(data.accounts)) {
    console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #00ff88; font-weight: bold');
    console.log('%c💰 COMPTES BANCAIRES (' + data.accounts.length + ')', 'color: #00ff88; font-weight: bold; font-size: 16px');
    console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #00ff88; font-weight: bold');
    console.log('');

    let totalBalance = 0;
    let totalTransactions = 0;

    data.accounts.forEach((account, index) => {
      console.log(`%c🏦 COMPTE ${index + 1}`, 'color: #ffaa00; font-weight: bold; font-size: 14px');
      console.log('   📌 Type:', account.type || 'N/A');
      console.log('   📌 Institution:', account.institution || 'N/A');
      console.log('   📌 Compte:', account.account || 'N/A');
      console.log('   📌 Transit:', account.transit || 'N/A');
      console.log('   💵 Balance disponible:', account.available_balance || '0.00', '$');
      console.log('   💵 Balance actuelle:', account.current_balance || '0.00', '$');

      if (account.current_balance) {
        totalBalance += parseFloat(account.current_balance) || 0;
      }

      if (account.transactions && Array.isArray(account.transactions)) {
        const txCount = account.transactions.length;
        totalTransactions += txCount;
        console.log('   📊 Transactions:', txCount);

        if (txCount > 0) {
          console.log('   📊 Première transaction:', {
            date: account.transactions[0].date,
            description: account.transactions[0].description,
            montant: account.transactions[0].amount
          });
        }
      }
      console.log('');
    });

    console.log('%c📈 RÉSUMÉ TOTAL', 'color: #00ff00; font-weight: bold; font-size: 14px');
    console.log('   📌 Nombre de comptes:', data.accounts.length);
    console.log('   📌 Balance totale:', totalBalance.toFixed(2), '$');
    console.log('   📌 Nombre de transactions:', totalTransactions);
    console.log('');
  }

  // Afficher le JSON COMPLET
  console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #ff00ff; font-weight: bold');
  console.log('%c📦 JSON COMPLET (clique pour développer)', 'color: #ff00ff; font-weight: bold; font-size: 16px');
  console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #ff00ff; font-weight: bold');
  console.log('');
  console.log(data);
  console.log('');

  // Afficher le JSON formaté
  console.log('%c📝 JSON FORMATÉ (copie-colle):', 'color: #00aaff; font-weight: bold; font-size: 14px');
  console.log(JSON.stringify(data, null, 2));
  console.log('');

  // Statistiques
  const jsonSize = JSON.stringify(data).length;
  console.log('%c📊 STATISTIQUES', 'color: #ffaa00; font-weight: bold; font-size: 14px');
  console.log('   📌 Taille JSON:', jsonSize, 'caractères');
  console.log('   📌 Taille JSON:', (jsonSize / 1024).toFixed(2), 'KB');
  console.log('   📌 Nombre de clés:', Object.keys(data).length);
  console.log('');
}

// ============================================
// 6. GÉRER LE CLICK
// ============================================
async function handleAnalyzeClick(event) {
  const button = event.currentTarget;
  const originalContent = button.innerHTML;

  console.log('');
  console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #00ff00; font-weight: bold');
  console.log('%c🎯 CLICK SUR LE BOUTON "AFFICHER JSON"', 'color: #00ff00; font-weight: bold; font-size: 18px');
  console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #00ff00; font-weight: bold');
  console.log('');
  console.log('   📌 Timestamp:', new Date().toISOString());
  console.log('   📌 GUID à récupérer:', guid);
  console.log('');

  // Désactiver le bouton
  button.disabled = true;
  button.innerHTML = `
    <div class="spinner"></div>
    <span>Récupération...</span>
  `;

  try {
    // Récupérer les données
    const inveriteData = await fetchInveriteData(guid);

    // Afficher toutes les données
    displayFullData(inveriteData);

    // Succès
    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
        <polyline points="22 4 12 14.01 9 11.01"></polyline>
      </svg>
      <span>✅ JSON affiché!</span>
    `;

    console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #00ff00; font-weight: bold');
    console.log('%c✅ SUCCÈS - TOUTES LES DONNÉES AFFICHÉES CI-DESSUS', 'color: #00ff00; font-weight: bold; font-size: 18px');
    console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: #00ff00; font-weight: bold');
    console.log('');

    // Restaurer le bouton après 2 secondes
    setTimeout(() => {
      button.disabled = false;
      button.innerHTML = originalContent;
    }, 2000);

  } catch (error) {
    console.log('');
    console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: red; font-weight: bold');
    console.log('%c❌ ERREUR FATALE', 'color: red; font-weight: bold; font-size: 18px');
    console.log('%c━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 'color: red; font-weight: bold');
    console.error('');
    console.error('📌 Type:', error.name);
    console.error('📌 Message:', error.message);
    console.error('📌 Stack complet:');
    console.error(error.stack);
    console.error('');

    // Afficher l'erreur
    button.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>
      <span>❌ ${error.message}</span>
    `;

    // Restaurer après 3 secondes
    setTimeout(() => {
      button.disabled = false;
      button.innerHTML = originalContent;
    }, 3000);
  }
}

console.log('%c✅ IBV CRAWLER V2 - MODE DEBUG PRÊT', 'color: #00ff00; font-weight: bold; font-size: 16px');
console.log('%c📋 Cliquez sur le bouton "Afficher JSON" pour voir les données', 'color: #00aaff');
console.log('');
