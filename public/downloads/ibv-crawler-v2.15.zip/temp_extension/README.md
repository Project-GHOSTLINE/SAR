# IBV Crawler V2.15 - SAR PRODUCTION

## Description

Extension Chrome officielle pour Solution Argent Rapide INC.

**Version:** 2.1.5
**Support:** Flinks + Inverite

## Fonctionnalités

- ✅ Support complet de l'API Flinks
- ✅ Support complet de l'API Inverite
- ✅ Extraction automatique des données client
- ✅ Fonction `findValue()` robuste pour récupérer les informations
- ✅ Envoi direct vers admin.solutionargentrapide.ca

## Installation

### Méthode 1: Chrome Web Store (Recommandé)
*Non disponible - Extension interne uniquement*

### Méthode 2: Chargement Manuel (Développeur)

1. **Extraire le fichier ZIP**
   - Décompressez `ibv-crawler-v2.15.zip` dans un dossier de votre choix

2. **Activer le mode développeur**
   - Ouvrez Chrome et allez dans `chrome://extensions/`
   - Activez le toggle "Mode développeur" en haut à droite

3. **Charger l'extension**
   - Cliquez sur "Charger l'extension non empaquetée"
   - Sélectionnez le dossier extrait contenant le fichier `manifest.json`

4. **Vérifier l'installation**
   - L'extension apparaîtra dans la liste avec l'ID: `icjjhbknppfpnfiooooajaggbmlbeagh`
   - L'icône apparaîtra dans la barre d'outils Chrome

## Utilisation

1. **Navigation**
   - Visitez un site supporté (Flinks ou Inverite)

2. **Extraction Manuelle**
   - Cliquez sur l'icône de l'extension
   - Cliquez sur "Extraire les données"

3. **Extraction Automatique**
   - L'extension détecte automatiquement les pages supportées
   - Les données sont envoyées directement à l'admin SAR

## Sécurité

⚠️ **ATTENTION - USAGE RESTREINT**

Cette extension est **strictement réservée** à l'équipe Solution Argent Rapide INC.

- ❌ Ne pas partager avec des tiers
- ❌ Ne pas distribuer publiquement
- ❌ Contient des clés API de production
- ✅ Usage interne uniquement

## Support

Pour toute question ou problème:

- **Email:** support@solutionargentrapide.ca
- **Admin:** https://admin.solutionargentrapide.ca
- **Documentation:** https://solutionargentrapide.ca/docs

## Changelog

### Version 2.1.5 (2026-01-13)
- ✅ Support Flinks optimisé
- ✅ Support Inverite optimisé
- ✅ Fonction `findValue()` améliorée
- ✅ Connexion admin.solutionargentrapide.ca stabilisée

---

© 2026 Solution Argent Rapide INC. - Tous droits réservés
