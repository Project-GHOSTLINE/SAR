// IBV Crawler V2.15 - Popup Script

document.getElementById('extractBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })

  chrome.tabs.sendMessage(tab.id, { action: 'extract' }, (response) => {
    if (response?.success) {
      console.log('Data extracted:', response.data)
      alert('Données extraites avec succès!')
    } else {
      alert('Erreur lors de l\'extraction')
    }
  })
})

document.getElementById('settingsBtn').addEventListener('click', () => {
  chrome.runtime.openOptionsPage()
})
