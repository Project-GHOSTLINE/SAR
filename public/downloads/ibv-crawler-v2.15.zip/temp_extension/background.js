// IBV Crawler V2.15 - SAR PRODUCTION
// Background Service Worker

console.log('IBV Crawler V2.15 - Background service worker loaded')

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractData') {
    // Handle data extraction
    console.log('Data extraction requested:', request.data)
    sendResponse({ success: true })
  }
  return true
})

// Initialize extension
chrome.runtime.onInstalled.addListener(() => {
  console.log('IBV Crawler V2.15 installed successfully')
})
