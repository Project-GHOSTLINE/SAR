// IBV Crawler V2.15 - SAR PRODUCTION
// Content Script

console.log('IBV Crawler V2.15 - Content script loaded')

// Robust findValue() for Customer Info
function findValue(selector, attribute = 'textContent') {
  try {
    const element = document.querySelector(selector)
    if (!element) return null

    if (attribute === 'textContent') {
      return element.textContent?.trim() || null
    }

    return element.getAttribute(attribute) || null
  } catch (error) {
    console.error('findValue error:', error)
    return null
  }
}

// Auto-detect and extract customer information
function extractCustomerInfo() {
  const data = {
    timestamp: new Date().toISOString(),
    source: window.location.hostname,
    customerInfo: {}
  }

  // Extract common fields
  const fields = [
    'name', 'firstName', 'lastName', 'email', 'phone',
    'address', 'city', 'province', 'postalCode',
    'loanAmount', 'loanTerm', 'employmentStatus'
  ]

  fields.forEach(field => {
    const value = findValue(`[data-field="${field}"]`) ||
                   findValue(`#${field}`) ||
                   findValue(`.${field}`)
    if (value) data.customerInfo[field] = value
  })

  return data
}

// Send data to background script
function sendToBackground(data) {
  chrome.runtime.sendMessage({
    action: 'extractData',
    data: data
  })
}

// Listen for extraction requests
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extract') {
    const data = extractCustomerInfo()
    sendResponse({ success: true, data })
  }
  return true
})
